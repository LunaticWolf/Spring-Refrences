package database;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;


public class GetConnection {

	private static Connection con = null;
	//InputStream in=null;

	public static Properties loadProperty()
	{
		Properties p=new Properties();
		 
		try {
			
			InputStream in  = new FileInputStream("db.properties");
			
			p.load(in);
			in.close();
		
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		}
catch (IOException e) {
			
			e.printStackTrace();
		}
		return p;
	  
	}
	
	
	
	public static Connection getConnection() {

		try {
			
			Properties prop = loadProperty();
			String driverClass = prop.getProperty("Oracle.JDBC.driver");
			Class.forName(driverClass);
			// System.out.println("Driver is registered..");
			String url = prop.getProperty("Oracle.JDBC.url");
			String username = prop.getProperty("Oracle.JDBC.username");
			String password = prop.getProperty("Oracle.JDBC.password");
			con = DriverManager.getConnection(url, username, password);
			//System.out.println("Connection Establish.....");

		} catch (ClassNotFoundException e) {

			e.printStackTrace();
		} catch (Exception e) {

			e.printStackTrace();
		}

		return con;
	}

	public void closeConnection() {

		try {
			if(con!=null)
			{con.close();}
		} catch (SQLException e) {

		}
	}

}
