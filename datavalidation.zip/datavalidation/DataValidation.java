package datavalidation;

import java.text.ParsePosition;
import java.text.SimpleDateFormat;
//import java.text.ParseException;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DataValidation {

	// 
	public boolean dataType(Object x,String type) {

		if(x.getClass().getSimpleName().equalsIgnoreCase(type))
		return true;
		else
		return   false;
		
	}

	// 

	public boolean dataLength(String S,int X) {

		
		if(S.length()<=X)
			return true;
			else
			return false;
	}

	// 
	public boolean specialCharacters(String pattern1,String matcher1) {
		int countc=0;
		String strArray[] = pattern1.split("");
        for(int i=1; i < strArray.length; i++)
        {
        	pattern1=strArray[i];
        Pattern pattern = Pattern.compile(pattern1);    
        
        Matcher matcher = pattern.matcher(matcher1);   
        boolean b = false;
        b = matcher.find();

        if (b==true)
        	countc++;
        }
        if(countc>0)	
              return true;
      //System.out.println("I found the text ");      
        else
              //	System.out.println("No match found.");
                return false;
	}

	// 

	public boolean domainValue(String fieldName,String list) {

	
		String l[]=list.split(" ");
		int size = l.length;
		int count=0;
	     for(int i=0;i<size;i++)
	     {
	    	 if(fieldName.equalsIgnoreCase(l[i]))
	    		 count++;
	    	 		 
	     }
	     if (count>0)
	    	 return true;
	     else 
	    	 return false;
		
	}
	
	// 

	public boolean formatValidation(String date, String dateFormat1) {
		
		
		if(date.trim().equals(""))
		{
			return false;
			
		}	
		else
		{
			try
			{
				SimpleDateFormat fmt = new SimpleDateFormat(dateFormat1);
				fmt.setLenient(false);
				Date D = fmt.parse(date);
				return true;
				
				
			}
			catch(Exception e)
			{				
				return false;
	}
			
			
			
		}
		
		
		
		
		
		
		
	}
	

	//
	
	public boolean specialValidation(String email) {
		
		String emailPattern = "^[a-zA-Z0-9.a-zA-Z0-9_a-zA-Z0-9]{1,20}@[a-zA-Z0-9]{1,20}.[.a-zA-Z]{1,6}$";
		
		Pattern pattern = Pattern.compile(emailPattern);    
        
        Matcher matcher = pattern.matcher(email);   
        
        boolean b = false;
        b = matcher.find();

        if (b==true)
        	//System.out.println("I found the text ");
        	return true;
        else
        //	System.out.println("No match found.");
        
        	return b;
        
	     
	}

	//
	
}
