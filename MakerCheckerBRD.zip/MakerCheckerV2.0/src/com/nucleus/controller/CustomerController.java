package com.nucleus.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.nucleus.model.Customer;
import com.nucleus.service.CustomerServiceImpl;
import com.nucleus.service.ICustomerService;
import com.nucleus.validation.Validation;


@WebServlet("/Customer")
public class CustomerController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
		protected void doProcessing(HttpServletRequest request,
				HttpServletResponse response) throws ServletException, IOException {

			response.setContentType("text/html");
			PrintWriter out = response.getWriter();

			HttpSession session = request.getSession(false);

			System.out.println(session);
			if (session == null) 
			{
				out.print("Please login first");
				//request.getRequestDispatcher("login.jsp").include(request, response);
				response.sendRedirect("login.jsp");
			}// end of session verification
			
			else 
			{
				//System.out.println("session");
				String userName= (String)session.getAttribute("userName");
				System.out.println("session"+userName);
				System.out.println("session bn gya");
				String jsppath=	"WEB-INF/jsp/";
				// ///////////////////////////////////////
				/*
				 * PrintWriter pw = response.getWriter();
				 * response.setContentType("text/html");
				 */

				String action = request.getParameter("action");

				/*String act = request.getParameter("action1");
				System.out.println(act);*/

				if (action.equalsIgnoreCase("new")) {
				String str=	"WEB-INF/jsp/new.jsp";
				System.out.println(" new hlink"); 
				RequestDispatcher rd = request
						.getRequestDispatcher(str);
				rd.include(request, response);
//				response.sendRedirect(str);
				}// open new jsp 
				
				if (action.equalsIgnoreCase("delete")) {
					String str=	"WEB-INF/jsp/delete.jsp";
					System.out.println("delete hlink"); 
					RequestDispatcher rd = request
							.getRequestDispatcher(str);
					rd.include(request, response);
					}// open delete jsp 
				
				
				if (action.equalsIgnoreCase("view")) {
					System.out.println("view hlink"); 
					RequestDispatcher rd = request
							.getRequestDispatcher(jsppath+"ViewUserById.jsp");
					rd.include(request, response);
					}// open viewbyid jsp 
					
				if (action.equalsIgnoreCase("update")) {
					System.out.println("update hlink"); 
					RequestDispatcher rd = request
							.getRequestDispatcher(jsppath+"update.jsp");
					rd.include(request, response);
					}// open viewall jsp 
					
				
///////////////////////////////////////////////////////////////////////////////////////////////////////// V I E W __				
				if (action.equalsIgnoreCase("AddUser")) {

					SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
					Date date1 = new Date();
					String date = (sdf.format(date1));

					// System.out.println("zxfxgfxcgfcjcgh");
					String s1 = request.getParameter("t1");
					String s2 = request.getParameter("t2");
					String s3 = request.getParameter("t3");
					String s4 = request.getParameter("t4");
					String s5 = request.getParameter("t5");
					String s6 = request.getParameter("t6");
					String s7 = request.getParameter("t7");
					String s8 = request.getParameter("t8");
					
					//String s9 = request.getParameter("t9");  record status no need
					
					String s10 = request.getParameter("t10");
					String s11 = request.getParameter("t11");
					// String s12=request.getParameter("t12");
					System.out.println("Set krne se phle");

					//CustomerDAO customerDAO = new CustomerDAO();
					Customer customer = new Customer();

					customer.setCustomer_code(s1);
					customer.setCustomer_name(s2);
					customer.setCustomer_address_1(s4);
					customer.setCustomer_address_2(s5);
					customer.setCustomer_pin_code(s3);
					customer.setEmail_address(s8);
					customer.setContact_number(s6);
					customer.setPrimary_contact_person(s7);
					customer.setRecord_status("N");
					customer.setActice_inactive_flag(s10);
					customer.setCreated_date(date);
					
					customer.setCreated_by(userName); //////
					System.out.println("created by"+userName);
					Validation v = new Validation();
					// v.isValidCustomer_code(str2[0], cvalid)&&
					System.out.println("validation krne se phle");

					if (v.isValidName(customer.getCustomer_name())
							&& v.isValidAddress1(customer.getCustomer_address_1())
							&& v.isValidPincode(customer.getCustomer_pin_code())
							&& v.isvalidEmail(customer.getEmail_address())
							&& v.isValidRecordStatus(customer.getRecord_status())
							&& v.isValidActiveinActiveflag(customer
									.getActice_inactive_flag())) {

						System.out.println("validation krne ke baad");
						//int ir = customerDAO.addUser(customer);
						ICustomerService i1=new CustomerServiceImpl();

					int ir =i1.addUser(customer);
						if (ir != 0) {
							//testing ritik
							//request.getRequestDispatcher("new.jsp").include(request, response);
						//yha tk
							//response.sendRedirect("login.jsp");
							out.println("updated...");
						
						} else {
							out.println("Problem in insertion");
						}

					}// end of validation

					else {
						out.println("Inavlid data Problem in insertion");
					}

				}// end of add user

				if (action.equalsIgnoreCase("DeleteUser")) {

					String s1 = request.getParameter("t1");
					try {

						Customer customer = new Customer();

						customer.setCustomer_code(s1);
						
						ICustomerService i1=new CustomerServiceImpl();
						
						int d = i1.deleteUser(customer);
						if (d == 0) {
							out.println("can't delete through this id");
						} else{
							request.getRequestDispatcher(jsppath+"delete.jsp").include(request, response);
							out.println("Entry Deleted successfully...!!!");
						}
					} catch (Exception e) {
						e.printStackTrace();
					}

				}// end of delete user

				if (action.equalsIgnoreCase("ViewUserById")) {
					String code = request.getParameter("t1");
					System.out.println("html se aa gya" + code);
					Customer customer = new Customer();

					customer.setCustomer_code(code);
					System.out.println("customer me aa gya"
							+ customer.getCustomer_code());
					
					ICustomerService i1=new CustomerServiceImpl();
					
					Customer result = i1.ViewUserById(customer);

					System.out.println(result.getCreated_by()+"result aa gya viewbyid");
					 /* HttpSession session=request.getSession();
					 session.setAttribute("uObject", result);*/
					 
					// response.sendRedirect("Search");
					// rrrrrjjj
					request.setAttribute("customer", result);

					// RequestDispatcher rd=
					// request.getRequestDispatcher("userList.jsp");
					RequestDispatcher rd = request
							.getRequestDispatcher(jsppath+"ViewUserById.jsp");
					rd.include(request, response);

					// /rrrrjjj

				}// end of view by id

				if (action.equalsIgnoreCase("ViewAll")) {

					ICustomerService i1=new CustomerServiceImpl();
					
					List<Customer> CustomerList = (List<Customer>) i1.viewUsers();

					request.setAttribute("CustomerList", CustomerList);

					// RequestDispatcher rd=
					// request.getRequestDispatcher("userList.jsp");
					RequestDispatcher rd = request.getRequestDispatcher(jsppath+"ViewAll.jsp");
					rd.include(request, response);

				}// end of viewall

				if (action.equalsIgnoreCase("UpdateUser")) {
					
					System.out.println("OOOOOOOOOOOOOOOOOOOOOO");
					System.out.println("Success");

					SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
					Date date1 = new Date();
					String date = (sdf.format(date1));

					String s1 = request.getParameter("t1");
					String s2 = request.getParameter("t2");
					String s3 = request.getParameter("t3");
					String s4 = request.getParameter("t4");
					System.out.println("controller"+s4);
					System.out.println("controller"+s1);
					String s5 = request.getParameter("t5");
					String s6 = request.getParameter("t6");
					String s7 = request.getParameter("t7");
					String s8 = request.getParameter("t8");
					// String s9=request.getParameter("t9");
					String s10 = request.getParameter("t10");
					// String s11=request.getParameter("t11");
					// String s12=request.getParameter("t12");
					System.out.println("Set krne se phle");

					ICustomerService i1=new CustomerServiceImpl();
					Customer customer = new Customer();

					customer.setCustomer_code(s1);
					customer.setCustomer_name(s2);
					// customer.setCustomer_address_1(s4);
					customer.setCustomer_address_1(s4);
					customer.setCustomer_address_2(s5);
					customer.setCustomer_pin_code(s3);
					customer.setEmail_address(s8);
					customer.setContact_number(s6);
					customer.setPrimary_contact_person(s7);
					 customer.setRecord_status("M");
					//customer.setRecord_status("N");
					customer.setActice_inactive_flag(s10);
					// customer.setModified_date(date);
					customer.setModified_by(userName);

					// //////////////
					System.out.println("database se phle");
					int ir = i1.updateByCode(customer);
					if (ir != 0) {
						out.println("updated...");
					} else {
						out.println("Problem in insertion");
					}

					// ///////////////

					
					/* * System.out.println("UPUPUPUUPUPPU"); String
					 * code=request.getParameter("t1"); Customer customer = new
					 * Customer(); customer.setCustomer_code(code); CustomerDAO
					 * customerDAO = new CustomerDAO(); Customer
					 * result=customerDAO.ViewUserById(customer);
					 * 
					 * request.setAttribute("Customer", result);
					 * System.out.println("1322222222222222222"); RequestDispatcher
					 * rd= request.getRequestDispatcher("Update");
					 * rd.include(request, response);
					 */

				}// end of update
				
				if (action.equalsIgnoreCase("Update1")) {
					
					String code = request.getParameter("t1");
					System.out.println("html se aa gya" + code);
					Customer customer = new Customer();

					customer.setCustomer_code(code);
					System.out.println("customer me aa gya"
							+ customer.getCustomer_code());
					
					ICustomerService i1=new CustomerServiceImpl();
					
					Customer result = i1.ViewUserById(customer);

					System.out.println(result.getCreated_by()+"result aa gya update ke form ke liye");
					
					request.setAttribute("customer", result);

					// RequestDispatcher rd=
					// request.getRequestDispatcher("userList.jsp");
					RequestDispatcher rd = request
							.getRequestDispatcher(jsppath+"update.jsp");
					rd.include(request, response);
				}
				
				// ///////////////////////////////////////////////////////
			}// end of if session !=null
			

		}// end of do
			// //////////////

		protected void doGet(HttpServletRequest request,
				HttpServletResponse response) throws ServletException, IOException {
			doProcessing(request, response);
		}

		protected void doPost(HttpServletRequest request,
				HttpServletResponse response) throws ServletException, IOException {
			doProcessing(request, response);
		}

	}// end of class

	
	
