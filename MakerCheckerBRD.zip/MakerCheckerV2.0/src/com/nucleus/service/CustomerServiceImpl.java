package com.nucleus.service;

import java.util.List;

import com.nucleus.dao.CustomerDAOFactory;
import com.nucleus.dao.ICustomerDAO;
import com.nucleus.model.Customer;

public class CustomerServiceImpl implements ICustomerService {

	@Override
	public int addUser(Customer customer) {
		
		
		ICustomerDAO customerDAO=CustomerDAOFactory.getCustomerImpl("rdbms");
		int addi = customerDAO.addUser(customer);
		System.out.println(addi+"queryrt");
		return addi;

	}
/////////////////////////////////////////
	public int deleteUser(Customer customer)
	{

		ICustomerDAO customerDAO=CustomerDAOFactory.getCustomerImpl("rdbms");
		int deli = customerDAO.deleteUser(customer);
		System.out.println(deli+"queryrt");
		return deli;
		
	}
	///////////////////////////////////////////////////
	public Customer ViewUserById(Customer customer)
	{
		ICustomerDAO customerDAO=CustomerDAOFactory.getCustomerImpl("rdbms");
		return	customerDAO.ViewUserById(customer);
	}
	//////////////////////////////////////
	
	public List<Customer> viewUsers()
	{
		ICustomerDAO customerDAO=CustomerDAOFactory.getCustomerImpl("rdbms");
		return	customerDAO.viewUsers();
	}
	///////////////////////////////////////
	
	public int updateByCode(Customer customer){
		ICustomerDAO customerDAO=CustomerDAOFactory.getCustomerImpl("rdbms");
		return	customerDAO.updateByCode(customer);
	}
	/////////////////////////////////////////
	
}
