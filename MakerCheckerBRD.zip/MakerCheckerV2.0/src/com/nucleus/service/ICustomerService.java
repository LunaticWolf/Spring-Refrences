package com.nucleus.service;

import java.util.List;

import com.nucleus.model.Customer;

public interface ICustomerService {

	public int addUser(Customer customer);
	
	public int deleteUser(Customer customer);
	
	public Customer ViewUserById(Customer customer);
	
	public List<Customer> viewUsers();
	
	public int updateByCode(Customer customer);
	
}
