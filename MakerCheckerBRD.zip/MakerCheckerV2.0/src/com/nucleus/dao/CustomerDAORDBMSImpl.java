package com.nucleus.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import com.nucleus.connection.ConnectionClass;
import com.nucleus.model.Customer;

public class CustomerDAORDBMSImpl implements ICustomerDAO{

	public int addUser(Customer customer) {
		
		Connection conn=null;
		PreparedStatement ps = null;
		int i=0;
		
		java.sql.Date date = new java.sql.Date(Calendar.getInstance().getTime().getTime());		
		try {
			ps = ConnectionClass
					.getConnection()
					.prepareStatement(
							"insert into RJCustomer values(S_CustomerBRD.NEXTVAL,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ");
			
			ps.setString(1,customer.getCustomer_code());
			ps.setString(2,customer.getCustomer_name());			
			ps.setString(3,customer.getCustomer_address_1());
			ps.setString(4,customer.getCustomer_address_2());
			ps.setString(5,customer.getCustomer_pin_code());
			ps.setString(6,customer.getEmail_address());
			ps.setString(7,customer.getContact_number());
			ps.setString(8,customer.getPrimary_contact_person());
			ps.setString(9,customer.getRecord_status());
			ps.setString(10,customer.getActice_inactive_flag());
			System.out.println(customer.getCreated_date()+"current date");
			ps.setString(11,customer.getCreated_date());
//			ps.setString(11,customer.getCreated_date());
			ps.setString(12,customer.getCreated_by());
			ps.setString(13,customer.getModified_date());
			ps.setString(14,customer.getModified_by());
			ps.setString(15,customer.getAuthorize_date());
			ps.setString(16,customer.getAuthorize_by());
			
		
			System.out.println(i+"querybeforeinsert");
			i = ps.executeUpdate();	
			System.out.println(i+"queryinsert");
			if(i!=0)
			 {
				 System.out.println("done");
			 }	
			
		} catch (SQLException e) {
			//System.out.println(e.getMessage() + customer_code + customer_name);
			// e.printStackTrace();
		}

		finally {
			
				/*try {
					ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}*/

		}//end of finally of add user
		return i;

		
	}// end of add user 
	
	public int deleteUser(Customer customer){
		
		Connection conn=null;
		PreparedStatement ps = null;
		int i=0;
		
		try {
			ps = ConnectionClass
					.getConnection()
					.prepareStatement(
							"delete from RJCustomer where CUSTCODE=?");
					ps.setString(1, customer.getCustomer_code());
			System.out.println("delete query");
			i=ps.executeUpdate();
			
		}
		catch(Exception e)
		{
			System.out.println("error in deleting");
		}
		return i;

	}//end of delete user
	
	
	public Customer ViewUserById(Customer customer){
	Connection conn= null;
	PreparedStatement psmt = null;
	ResultSet rs= null;
	try{
		
		conn = ConnectionClass.getConnection();
	 psmt = conn
				.prepareStatement("Select * from RJCustomer where CUSTCODE=?");
		
		psmt.setString(1, customer.getCustomer_code());
		 rs = psmt.executeQuery();

		while (rs.next()) {
			int s1=rs.getInt(1);
			String s2= rs.getString(2);
			String s3= rs.getString(3);
			String s4= rs.getString(4);
			//System.out.println("vvvvvvvvvvvvvvvvvvvvv"+s4);
			String s5= rs.getString(5);
			
			String s6= rs.getString(6);
			String s7= rs.getString(7);
			String s8= rs.getString(8);
			String s9= rs.getString(9);
			String s10= rs.getString(10);
			//System.out.println("vvvvvvvvvvvvvvvvvvvvv"+s9);
			String s11= rs.getString(11);
			String s12= rs.getString(12);
			String s13= rs.getString(13);
			//System.out.println("vvvvvvvvvvvvvvvvvvvvv"+s12);
			customer.setCustomer_Id(s1);
			customer.setCustomer_code(s2);
			customer.setCustomer_name(s3);
			customer.setCustomer_address_1(s4);
			customer.setCustomer_address_2(s5);
			customer.setCustomer_pin_code(s6);
			customer.setEmail_address(s7);
			customer.setContact_number(s8);
			customer.setPrimary_contact_person(s9);
			customer.setRecord_status(s10);
			customer.setActice_inactive_flag(s11); 	
			
			//System.out.println("Customer No." + rs.getInt(1)	+ "\n Customer Name " + rs.getString(2));	
			
		}
		
		
	}catch(Exception e){e.printStackTrace();}
	return customer;
	
	
}// end of view user by id
////////////////////
	
	
	public List<Customer> viewUsers(){
		List<Customer> CustomerList= new ArrayList<Customer>();
		Connection conn= null;
		PreparedStatement psmt = null;
		ResultSet rs= null;
		try{
			conn = ConnectionClass.getConnection();
		    psmt = conn.prepareStatement("Select * from RJCustomer");
			rs = psmt.executeQuery();
			while(rs.next()){
				int s1=rs.getInt(1);
				String s2= rs.getString(2);
				String s3= rs.getString(3);
				String s6= rs.getString(6);
				String s7= rs.getString(7);
				String s8= rs.getString(8);
				String s9= rs.getString(9);
				String s10= rs.getString(10);
				String s11= rs.getString(11);
				String s12= rs.getString(12);
				String s13= rs.getString(13);
				System.out.println("all"+s12);
				
				Customer customer = new Customer();
				customer.setCustomer_Id(s1);
				customer.setCustomer_code(s2);
				customer.setCustomer_name(s3);
				customer.setCustomer_pin_code(s6);
				customer.setEmail_address(s7);
				customer.setContact_number(s8);
				customer.setPrimary_contact_person(s9);
				customer.setRecord_status(s10);
				customer.setActice_inactive_flag(s11); 		
				customer.setCreated_date(s12);
				customer.setCreated_by(s13);
				
				CustomerList.add(customer);
			}
			
			
		}catch(Exception e){e.printStackTrace();}
		
		return CustomerList;
	}// end of view all
	
////////////////////////////////////////////////////	
	
	public int updateByCode(Customer customer){
		Connection conn= null;
		PreparedStatement ps = null;
		int i=0;
		
			try {
				
				System.out.println("cust code:-"+customer.getCustomer_code());
				ps = ConnectionClass
						.getConnection()
						.prepareStatement(
								"update  RJCustomer set CUSTNAME=?,CUSTADD1=?,CUSTADD2=?,CUSTPINCODE=?,EMAIL=?,CONTACTNO=?,PRIMARYCONTACT=?,RECORDSTATUS=?,AIFLAG=?, MODIFYBY=? where CUSTCODE=?");
				
				//,MODIFYDATE=?
				ps.setString(1,customer.getCustomer_name());			
				ps.setString(2,customer.getCustomer_address_1());
				ps.setString(3,customer.getCustomer_address_2());
				ps.setString(4,customer.getCustomer_pin_code());
				ps.setString(5,customer.getEmail_address());
				ps.setString(6,customer.getContact_number());
				ps.setString(7,customer.getPrimary_contact_person());
				ps.setString(8,customer.getRecord_status());
				ps.setString(9,customer.getActice_inactive_flag());
				
			//	ps.setString(10,customer.getModified_date());
				ps.setString(10,customer.getModified_by());
				ps.setString(11,customer.getCustomer_code());
			System.out.println("query tk");
				
				i = ps.executeUpdate();	
			i=ps.executeUpdate();
			if(i!=0)
			{
				System.out.println("Updated");
				}
			else{
				System.out.println("Invalid");
			}
				
			
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		return i;
		
		
	}// end of update
	///////////////////////////////////
}// end of class
