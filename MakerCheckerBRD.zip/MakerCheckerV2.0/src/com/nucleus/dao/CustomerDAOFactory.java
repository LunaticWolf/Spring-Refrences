package com.nucleus.dao;

public class CustomerDAOFactory {

	public static ICustomerDAO getCustomerImpl(String ImplType)
	{
		ICustomerDAO customerDAO=null;
		
		
	if(ImplType.equals("rdbms"))
	{
	customerDAO=new CustomerDAORDBMSImpl();
	}
	else if(ImplType.equals("xml"))
	{
	customerDAO=new CustomerDAOXmlImpl();
	}
	return customerDAO;
	
		
}
	
}