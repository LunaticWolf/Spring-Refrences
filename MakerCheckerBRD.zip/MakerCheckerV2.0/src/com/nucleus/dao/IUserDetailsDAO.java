package com.nucleus.dao;

import com.nucleus.model.UserDetails;

public interface IUserDetailsDAO {

	public UserDetails isLoginExist(UserDetails userDetails);
	
	public int userRegister(UserDetails userDetails);
	
}
