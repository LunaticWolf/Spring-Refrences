package com.nucleus.dao;

import java.util.List;

import com.nucleus.model.Customer;

public interface ICustomerDAO {

 public	int addUser(Customer customer);
 
 public int deleteUser(Customer customer);

 public Customer ViewUserById(Customer customer);
 
 public List<Customer> viewUsers();
 
 public int updateByCode(Customer customer);
 
}
