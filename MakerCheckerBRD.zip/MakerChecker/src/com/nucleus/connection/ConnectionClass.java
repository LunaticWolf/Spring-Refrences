package com.nucleus.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionClass {

public static Connection getConnection() {
		
		Connection con=null;

		try {

			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection("jdbc:oracle:thin:@10.1.50.198:1521:orcl", "sh", "sh");

		} catch (ClassNotFoundException | SQLException e) {

			e.printStackTrace();

		}

		return con;

	}

	
	
	
}
