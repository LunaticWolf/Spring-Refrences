package com.nucleus.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.nucleus.dao.CustomerDAO;
import com.nucleus.model.Customer;
import com.nucleus.model.Validation;


@WebServlet("/CustomerController")

public class CustomerController extends HttpServlet {
	
	protected void doProcessing(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		/*PrintWriter pw = response.getWriter();
		response.setContentType("text/html");  */
		
		String action = request.getParameter("action");
		
		if (action.equalsIgnoreCase("AddUser")) {
			
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			Date date1 = new Date();
			String date = (sdf.format(date1));
			
			
			//System.out.println("zxfxgfxcgfcjcgh");
			String s1=request.getParameter("t1");
			String s2=request.getParameter("t2");
			String s3=request.getParameter("t3");
			String s4=request.getParameter("t4");
			String s5=request.getParameter("t5");
			String s6=request.getParameter("t6");
			String s7=request.getParameter("t7");
			String s8=request.getParameter("t8");
			String s9=request.getParameter("t9");
			String s10=request.getParameter("t10");
			String s11=request.getParameter("t11");
			//String s12=request.getParameter("t12");
			System.out.println("Set krne se phle");
			
			CustomerDAO customerDAO = new CustomerDAO();
			Customer customer = new Customer();
			
			customer.setCustomer_code(s1);
			customer.setCustomer_name(s2);
			customer.setCustomer_address_1(s4);
			customer.setCustomer_address_2(s5);
			customer.setCustomer_pin_code(s3);
			customer.setEmail_address(s8);
			customer.setContact_number(s6);
			customer.setPrimary_contact_person(s7);
			customer.setRecord_status(s9);
			customer.setActice_inactive_flag(s10);
			customer.setCreated_date(date);
			customer.setCreated_by("ritik");
			
			Validation v = new Validation();
			//v.isValidCustomer_code(str2[0], cvalid)&&
			System.out.println("validation krne se phle");
			
			if (
					 v.isValidName(customer.getCustomer_name())
					&& v.isValidAddress1(customer.getCustomer_address_1())
					&& v.isValidPincode(customer.getCustomer_pin_code())
					&& v.isvalidEmail(customer.getEmail_address())
					&& v.isValidRecordStatus(customer.getRecord_status())
					&& v.isValidActiveinActiveflag(customer.getActice_inactive_flag())) {
			
		
				System.out.println("validation krne ke baad");
			int ir=customerDAO.addUser(customer);
			if(ir!=0)
			{
				out.println("updated...");
			}
			else{
					out.println("Problem in insertion");
			}
			
			}//end of validation
			
			else
			{
				out.println("Inavlid data Problem in insertion");
			}
			
			
		}//end of add user
		
		if(action.equalsIgnoreCase("DeleteUser"))
		{
		
			String s1=request.getParameter("t1");
			try{
				
				CustomerDAO customerDAO = new CustomerDAO();
				Customer customer = new Customer();
				
				customer.setCustomer_code(s1);
				
				System.out.println(s1);		
				int d = customerDAO.deleteUser(customer);
				if(d==0){
					out.println("can't delete through this id");
				}
				else
					out.println("Entry Deleted successfully...!!!");
				
			}catch(Exception e)
			{e.printStackTrace();}
			
		
		}//end of delete user
		
		
		if(action.equalsIgnoreCase("ViewUserById"))
		{
			String code=request.getParameter("t1");       
			System.out.println("html se aa gya"+code);
			Customer customer = new Customer();
			
			customer.setCustomer_code(code);
			System.out.println("customer me aa gya"+customer.getCustomer_code());
			CustomerDAO customerDAO = new CustomerDAO();
			Customer result=customerDAO.ViewUserById(customer);		
					
			/*HttpSession session=request.getSession();
					session.setAttribute("uObject", result);*/	
			//response.sendRedirect("Search");		
			//rrrrrjjj
			request.setAttribute("Customer", result);
			
			//RequestDispatcher rd= request.getRequestDispatcher("userList.jsp");
			RequestDispatcher rd= request.getRequestDispatcher("ViewUserById");
			rd.include(request, response);
			
			
			///rrrrjjj
			
		}// end of view by id
		
		if(action.equalsIgnoreCase("ViewAll"))
		{
			
			CustomerDAO customerDAO = new CustomerDAO();
			//CrudModel abc=new CrudModel();
			List<Customer> CustomerList = (List<Customer>)customerDAO.viewUsers();
			
			
			request.setAttribute("CustomerList", CustomerList);
			
			//RequestDispatcher rd= request.getRequestDispatcher("userList.jsp");
			RequestDispatcher rd= request.getRequestDispatcher("ViewAll");
			rd.include(request, response);
			
		}//end of viewall
		
		
		
		
		
}// end of do

protected void doGet(HttpServletRequest request,
		HttpServletResponse response) throws ServletException, IOException {
	doProcessing(request, response);
}

protected void doPost(HttpServletRequest request,
		HttpServletResponse response) throws ServletException, IOException {
	doProcessing(request, response);
}


}//end of class
