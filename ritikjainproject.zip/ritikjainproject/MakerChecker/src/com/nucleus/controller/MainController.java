package com.nucleus.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.nucleus.dao.UserDetailsDAO;
import com.nucleus.model.UserDetails;
import com.nucleus.model.Validation;


@WebServlet("/MainController")

public class MainController extends HttpServlet {
	

	protected void doProcessing(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		PrintWriter pw = response.getWriter();
		response.setContentType("text/html");

		String action = request.getParameter("action");
/////////////////////////////////////////////////////////////////
		
		if (action.equalsIgnoreCase("Login")) {
			int userId = Integer.parseInt(request.getParameter("userId"));
			String userPassword = request.getParameter("userPassword");
			String userRole = request.getParameter("userRole");

			UserDetails userDetails = new UserDetails(userId, userPassword,
					userRole);

			Validation v = new Validation();

			boolean b = v.isExist(userDetails);

			if (b == true) {// valid user
				
				if(userRole.equalsIgnoreCase("maker"))
				{
				response.sendRedirect("maker.jsp");  
				}
				else{
					response.sendRedirect("checker.jsp");
				}
				/*RequestDispatcher rd = request.getRequestDispatcher("Servlet2");
				rd.forward(request, response);*/
			} else {

				request.setAttribute("errorMessage",
						"Please Enter Valid details");
				request.getRequestDispatcher("login.jsp").forward(request,
						response);

			}

		} // end of if login
		
		if (action.equalsIgnoreCase("Register")) 
		{
			int userId = Integer.parseInt(request.getParameter("userId"));
			String userPassword = request.getParameter("userPassword");
			String userRole = request.getParameter("userRole");

			UserDetails userDetails = new UserDetails(userId, userPassword,
					userRole);

			Validation v = new Validation();

			boolean b = v.isExist(userDetails);

			if (b == true) {
				
				request.setAttribute("errorMessage",
						"Already Registered");
				//response.sendRedirect("registeration.jsp");  
			request.getRequestDispatcher("registeration.jsp").forward(request,response);
//				response.sendRedirect("maker.jsp");  
				/*RequestDispatcher rd = request.getRequestDispatcher("Servlet2");
				rd.forward(request, response);*/
			} else {
				
				if(v.isValidName(userPassword))
				{
					UserDetailsDAO udo = new UserDetailsDAO();
					
					 udo.UserDetailsDbOperationSave(userDetails);
					
					request.setAttribute("errorMessage",
						"Successfully registered");
			
				request.getRequestDispatcher("login.jsp").forward(request,
						response);
				
//				pw.println("<br>"+userId+userPassword+userRole);
				//response.sendRedirect("login.jsp");  
		
				}
				}
			
			
			
			
		}//end of register
		
		

	}// end of do

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doProcessing(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doProcessing(request, response);
	}

}
