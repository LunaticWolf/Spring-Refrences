package com.nucleus.view;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.nucleus.model.Customer;

@WebServlet("/ViewUserById")

public class ViewUserById extends HttpServlet {
	
	protected void doProcessing(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		
	
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		out.println("<a href='new.jsp'>Add New Employee</a>");
		out.println("<h1>Employees List</h1>");
		
		Customer customer = (Customer)request.getAttribute("Customer"); 
		//List<Emp> list=EmpDao.getAllEmployees();
		
		out.print("<table border='1' width='100%'");
		out.print("<<tr><th>CUSTOMER_ID</th><th>CUSTOMER_CODE</th><th>CUSTOMER_NAME</th><th>CUSTOMER_PIN_CODE</th><th>E_MAIL_ADDRESS</th><th>RECORD_STATUS</th><th>ACTIVE_INACTIVE_FLAG</th></tr>");
	
	/*	for(CrudModel user:result){*/
/*			System.out.println("122222aa3333aa");
			System.out.println(user.getCustomerCode());
*/			out.print("<tr><td>"+customer.getCustomer_Id()+"</td><td>"+customer.getCustomer_code()+"</td><td>"+customer.getCustomer_name()+"</td><td>"+customer.getCustomer_pin_code()+"</td><td>"+customer.getEmail_address()+"</td><td>"+customer.getRecord_status()+"</td><td>"+customer.getActice_inactive_flag()+"</td></tr>");
		//}
		out.print("</table>");
		
	//	out.close();
	
		
	
	}// end of doprocess
	
	
	///////////////////////////////
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doProcessing(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doProcessing(request, response);
	}

}
