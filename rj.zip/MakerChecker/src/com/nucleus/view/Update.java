package com.nucleus.view;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.nucleus.dao.CustomerDAO;
import com.nucleus.model.Customer;

@WebServlet("/Update")

public class Update extends HttpServlet {
	
	protected void doProcessing(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		 
		String code=request.getParameter("t1");       
		Customer customer1 = new Customer();
		customer1.setCustomer_code(code);
		CustomerDAO customerDAO = new CustomerDAO();
		Customer customer=customerDAO.ViewUserById(customer1);	
	        
	        out.println("<h1>Update Employee</h1>");  
	 
	        
	      //  Customer customer= (Customer)request.getAttribute("Customer");   
	          
	       /* out.print("<form action='EditServlet2' method='post'>");  
	        out.print("<table>");  
	        out.print("<tr><td></td><td><input type='hidden' name='id' value='"+e.getId()+"'/></td></tr>");  
	        out.print("<tr><td>Name:</td><td><input type='text' name='name' value='"+e.getName()+"'/></td></tr>");  
	        out.print("<tr><td>Password:</td><td><input type='password' name='password' value='"+e.getPassword()+"'/>   </td></tr>");  
	        out.print("<tr><td>Email:</td><td><input type='email' name='email' value='"+e.getEmail()+"'/></td></tr>");  
	        out.print("<tr><td>Country:</td><td>");  
	        out.print("<select name='country' style='width:150px'>");  
	        out.print("<option>India</option>");  
	        out.print("<option>USA</option>");  
	        out.print("<option>UK</option>");  
	        out.print("<option>Other</option>");  
	        out.print("</select>");  
	        out.print("</td></tr>");  
	        out.print("<tr><td colspan='2'><input type='submit' value='Edit & Save '/></td></tr>");  
	        out.print("</table>");  
	        out.print("</form>");  */
	        
	        System.out.println("txtfielld"+customer.getCustomer_address_1());
	          
	        
	        out.println("<form action=CustomerController>Update Details:-<br>"); 
			out.println("Customer id<input type=text name=t0 value="+customer.getCustomer_Id()+"><br>Customer code "+customer.getCustomer_code()+ "<input type='hidden' name=t1 value="+customer.getCustomer_code()+">"+
				 		"<br>Customer name<input type=text name=t2 value="+customer.getCustomer_name()+">"+
						"<br>Customer address1<textarea name=t4 rows=10 cols=30 >"+customer.getCustomer_address_1()+"</textarea>"+
						"<br>Customer address2<textarea name=t5 rows=10 cols=30 value="+customer.getCustomer_address_2()+"></textarea>"+
						"<br>Customer pincode<input type=text name=t3 value="+customer.getCustomer_pin_code()+">"+
						 "<br>Customer email<input type=text name=t8 value="+customer.getEmail_address()+">"+
						"<br>Customer contact no.<input type=text name=t6 value="+customer.getContact_number()+">"+
						"<br>Customer contact person<input type=text name=t7 value="+customer.getPrimary_contact_person()+">"+
					"<br><select name=t10 value=><option value=A>Active</option><option value=I>Inactive</option></select>");
			  out.println("<br><input type=submit name=action value=Update>"+"</form>");
			 
	        
	        
	        out.close();  
		
		
		
		
		
		
		
		
		
	
	}//end of do
	

protected void doGet(HttpServletRequest request,
		HttpServletResponse response) throws ServletException, IOException {
	doProcessing(request, response);
}

protected void doPost(HttpServletRequest request,
		HttpServletResponse response) throws ServletException, IOException {
	doProcessing(request, response);
}

}//end of class
	
       
    