package com.nucleus.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.nucleus.connection.ConnectionClass;
import com.nucleus.model.UserDetails;

public class UserDetailsDAO {


public boolean UserDetailsDbOperation(UserDetails userDetails) {
		
		int number = userDetails.getUserId(); 
		String password = userDetails.getUserPassword();
		String userRole = userDetails.getUserRole();
		int count=0;
		
		try{
		Connection conn;
		conn = ConnectionClass.getConnection();
			PreparedStatement psmt = conn
					.prepareStatement("Select * from UserDetailsLogin");
			ResultSet rs = psmt.executeQuery();

			while (rs.next()) {
				
				if( number==rs.getInt(1) && password.equals(rs.getString(2)) && userRole.equals(rs.getString(3)) ) 
				{
					count++;
					break;
				}
						
				//System.out.println("Customer No." + rs.getInt(1)	+ "\n Customer Name " + rs.getString(2));
			}

		} catch (SQLException e) {

			e.printStackTrace();

		}

		if(count>0)
		{
			System.out.println("Valid LOgin");
			return true;
			
		}
		else
		{
			return false;
			//System.out.println("InValid");
		}	
	}


public void UserDetailsDbOperationSave(UserDetails userDetails) {
	
	
	int count=0;

	Connection conn;
	conn = ConnectionClass.getConnection();
		PreparedStatement psmt;
		try {
			psmt = conn
					.prepareStatement("insert into UserDetailsLogin values (?,?,?)");
			
psmt.setInt(1, userDetails.getUserId());
psmt.setString(2, userDetails.getUserPassword());
psmt.setString(3, userDetails.getUserRole());

	psmt.executeUpdate();
	System.out.println("Success Login Registered");
		} catch (SQLException e) {

			e.printStackTrace();
		}
	
	finally
	{
		
	}
	
}
}
	
	
