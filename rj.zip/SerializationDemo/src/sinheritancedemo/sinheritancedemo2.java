package sinheritancedemo;

import java.io.BufferedOutputStream;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;



class Nucleus implements Serializable {

	int workstation_no;

	public Nucleus() {

	}

	public Nucleus(int workstation_no) {
		this.workstation_no = workstation_no;
	}

}

class Student extends Nucleus {
	int sid;
	String sname;

	public Student(int sid, String sname) {

		this.sid = sid;
		this.sname = sname;
	}

}

public class sinheritancedemo2 {

	public void save(Nucleus s) {
		try {

			FileOutputStream fos = new FileOutputStream("ParentSerializeC.txt",true);
			BufferedOutputStream bos = new BufferedOutputStream(fos); 
			ObjectOutputStream oos = new ObjectOutputStream(bos);
			oos.writeObject(s);
			oos.flush();
			System.out.println("success");

		} catch (Exception e) {

		}
	}
	//////////////////////////
	
	public void retrieve() {
		ObjectInputStream ois = null;
		try {
			FileInputStream fis = new FileInputStream("ParentSerializeC.txt");
			ois = new ObjectInputStream(fis);
			try{
				boolean cont = true;
				
			while(cont)
			{
				
			Student s = (Student) ois.readObject();
			if(s!=null)
			System.out.println(s.sid + " " + s.sname);
			else
				cont=false;
			}
			}
			catch(EOFException e)
			{
				System.out.println("File Completed");
			}
			
			
			
		} catch (Exception e) {

		} finally {
			try {
				ois.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}
	
	
	
	
	/////////////////////////

	public static void main(String args[]) {

		sinheritancedemo2 sd = new sinheritancedemo2();
		 Student s1 = new Student(1, "Ritik123");
		Student s2 = new Student(2, "Ritik Jain123");
		sd.save(s1);
		sd.save(s2);
		sd.retrieve();
		//Nucleus n = new Nucleus(35);
		//sd.save(n);

	}

}
