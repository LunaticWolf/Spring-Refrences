package sinheritancedemo;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;




class Nucleus
{

	int workstation_no;
	
}





class Student extends Nucleus implements Serializable {
	int sid;
	String sname;

	public Student(int sid, String sname) {

		this.sid = sid;
		this.sname = sname;
	}

}


public class sinheritancedemo {

	
	public void save(Student s) {
		try {

			FileOutputStream fos = new FileOutputStream("P_ChildS.txt");
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(s);
			oos.flush();
			System.out.println("success");

		} catch (Exception e) {

		}
	}
	
	
	
	
	public static void main(String[] args) {
		

		sinheritancedemo sd = new sinheritancedemo();
		Student s1 = new Student(1, "Aman");
		// Student s2= new Student (2,"Ritik");
		sd.save(s1);

		
		
		
	}

}
