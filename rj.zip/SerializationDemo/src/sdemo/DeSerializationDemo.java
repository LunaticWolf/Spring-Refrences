package sdemo;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

public class DeSerializationDemo {

	public void retrieve() {
		ObjectInputStream ois = null;
		try {
			FileInputStream fis = new FileInputStream("abc.txt");
			ois = new ObjectInputStream(fis);
			Student s = (Student) ois.readObject();
			System.out.println(s.sid + " " + s.sname);

		} catch (Exception e) {

		} finally {
			try {
				ois.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}

	public static void main(String[] args) {

		DeSerializationDemo ds = new DeSerializationDemo();
		ds.retrieve();

	}

}
