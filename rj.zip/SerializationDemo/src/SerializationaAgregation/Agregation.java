package SerializationaAgregation;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;



class A implements Serializable
{
int aid;
String aname;
}



public class Agregation  {

	
	public void save(A a) {
		try {

			FileOutputStream fos = new FileOutputStream("Aggregation.txt");
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(a);
			oos.flush();
			System.out.println("success");

		} catch (Exception e) {
			System.out.println("Fail");
		}
	}
	
	
	public static void main(String[] args) {
		Agregation ag = new Agregation();
		A a= new A();
		ag.save(a);
		
		
	}

}
