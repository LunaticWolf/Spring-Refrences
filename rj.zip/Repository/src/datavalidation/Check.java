package datavalidation;

import java.util.Scanner;

public class Check {

	int customer;
	// Integer i2=customer;
	static float coname;
	double c;
	String e = "Raj";

	public static void main(String args[])

	{
		Scanner scan = new Scanner(System.in);
		DataValidation DV = new DataValidation();

		System.out
				.println("Enter your Vaildation choice :- \n 1.Data Type \n 2.Data Length \n 3.Special Characters \n 4.Domain Value \n 5.Format Validation \n 6.Special Validation\n");
		String s = scan.nextLine();
		int n = Integer.valueOf(s);
		//
		switch (n)        // choosing the case

		{

		case 1:
		//
		{
			// Integer i = new Integer(20);
			System.out.println("Enter Type:");

			String type = scan.nextLine();

			// String type = "float";
			boolean b1 = DV.dataType(10.2f, type);
			System.out.println("The Field Type is correct ? \nThe answer is \n"
					+ b1);

		}
			break;
		//

		case 2: {
			System.out.println("Enter Field Name:");
			String str = scan.nextLine();

			System.out.println("Enter Maximum Limit:");
			int maxLimit = scan.nextInt();

			boolean b2 = DV.dataLength(str, maxLimit);
			System.out
					.println("The Field Limit is correct ? \nThe answer is \n"
							+ b2);
		}
			break;

		case 3: {
			System.out.println("Enter the pattern:\n");
			String pattern1 = scan.nextLine();

			System.out.println("Enter text:");
			String matcher1 = scan.nextLine();
			boolean b3 = DV.specialCharacters(pattern1, matcher1);
			System.out
					.println("The Field contain special characters ? \nThe answer is \n"
							+ b3);
		}
			break;

		case 4: {
			System.out.println("Enter the Field Name :- \n");
			String fieldName = scan.nextLine();

			System.out.println("Enter the list of field names :- \n");
			String list = scan.nextLine();
			// System.out.println("Enter the list of field names :- \n");

			boolean b4 = DV.domainValue(fieldName, list);
			System.out.println("The Field name is valid ? \nThe answer is \n"
					+ b4);
		}
			break;
		//
		case 5: {
			System.out.println("Enter the Date :- \n");
			String date = scan.nextLine();
			System.out.println("Enter the Date Format :- \n");
			String dateFormat1 = scan.nextLine();
			boolean b5 = DV.formatValidation(date, dateFormat1);
			System.out.println("The Date Field is valid ? \nThe answer is \n"
					+ b5);

		}
			break;
		//
		case 6: {
			System.out.println("Enter the email :- \n");

			String email = scan.next();
			boolean b6 = DV.specialValidation(email);
			System.out.println("The Email is valid ? \nThe answer is \n" + b6);
		}
			break;
		//
		default:
			System.out.println("Invalid choice");

		}

		//

	}

}
