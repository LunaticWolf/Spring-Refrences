package com.ritik.controller;

import com.ritik.model.Validation;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ritik.model.UserDetails;

@WebServlet("/Servlet1")
public class Servlet1 extends HttpServlet {

	protected void doProcessing(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		PrintWriter pw = response.getWriter();
		response.setContentType("text/html");

		String action = request.getParameter("action");
/////////////////////////////////////////////////////////////////
		
		if (action.equalsIgnoreCase("Login")) {
			int userId = Integer.parseInt(request.getParameter("userId"));
			String userPassword = request.getParameter("userPassword");
			String userRole = request.getParameter("userRole");

			UserDetails userDetails = new UserDetails(userId, userPassword,
					userRole);

			Validation v = new Validation();

			boolean b = v.isExist(userDetails);

			if (b == true) {
				RequestDispatcher rd = request.getRequestDispatcher("Servlet2");
				rd.forward(request, response);
			} else {

				request.setAttribute("errorMessage",
						"Please Enter Valid details");
				request.getRequestDispatcher("log.jsp").forward(request,
						response);

			}

		} // end of if login
		
		
		

	}// end of do

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doProcessing(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doProcessing(request, response);
	}

}
