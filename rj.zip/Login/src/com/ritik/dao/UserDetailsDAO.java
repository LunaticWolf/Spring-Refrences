package com.ritik.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.ritik.connection.ConnectionClass;
import com.ritik.model.UserDetails;

public class UserDetailsDAO {

	public boolean UserDetailsDbOperation(UserDetails userDetails) {
		
		int number = userDetails.getUserId(); 
		String password = userDetails.getUserPassword();
		int count=0;
		
		try{
		Connection conn;
		conn = ConnectionClass.getConnection();
			PreparedStatement psmt = conn
					.prepareStatement("Select * from customer3196");
			ResultSet rs = psmt.executeQuery();

			while (rs.next()) {
				
				if(number==rs.getInt(1) && password.equals(rs.getString(2) ))
				{
					count++;
					break;
				}
						
				//System.out.println("Customer No." + rs.getInt(1)	+ "\n Customer Name " + rs.getString(2));
			}

		} catch (SQLException e) {

			e.printStackTrace();

		}

		if(count>0)
		{
			return true;
			//System.out.println("Valid");
		}
		else
		{
			return false;
			//System.out.println("InValid");
		}	
	}

}
	
	
