package com.ritik.model;

import java.io.Serializable;

public class UserDetails implements Serializable {

	private int userId;
	private String userPassword;
	private String userRole;
	
	
	public UserDetails(int userId, String userPassword, String userRole) {
		this.userId = userId;
		this.userPassword = userPassword;
		this.userRole = userRole;
	}
	
	
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getUserPassword() {
		return userPassword;
	}
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	public String getUserRole() {
		return userRole;
	}
	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}
	
	
	
	
	
	
	
	
}