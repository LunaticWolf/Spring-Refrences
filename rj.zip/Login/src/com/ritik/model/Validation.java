package com.ritik.model;

import com.ritik.dao.UserDetailsDAO;

public class Validation {

	public boolean isExist(UserDetails userDetails)
	
	{
		//System.out.println("Validation tk"+userDetails.getUserID() +userDetails.getUserpassword());
	
	UserDetailsDAO udo = new UserDetailsDAO();
	
	boolean b= udo.UserDetailsDbOperation(userDetails);
	return b;
	}
	
}
