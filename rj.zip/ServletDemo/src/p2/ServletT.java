package p2;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ServletT")

public class ServletT extends HttpServlet {

	protected void doProcessing(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int z=0;
		PrintWriter pw = response.getWriter();
		response.setContentType("text/html");
		
		int n =Integer.parseInt(request.getParameter("n"));
		int s = Integer.parseInt(request.getParameter("s"));
		int e = Integer.parseInt(request.getParameter("e"));
		
	//	pw.println( n + s + e);
		
		Table1 t1 = new Table1();
		
		pw.println("<html><body> <table> <tr> <th>TABLE</th>  </tr>");
		for(int i=s;i<=e;i++)
		{
		z = t1.getTable(i, e, n);
		
		pw.println("<tr>"+ "<td> "+n+"x</td>" + "<td>"+i+"</td>" +  "<td> = "+z+"</td> </tr>");
		
		}
		pw.println(" </table></body></html>");
		
		
	}

 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doProcessing(request, response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doProcessing(request, response);
	}

}





	