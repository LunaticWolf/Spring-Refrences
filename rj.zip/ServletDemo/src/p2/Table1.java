package p2;

public class Table1 {

	public int getTable(int s,int e,int n)
	{
		
	/*	for(int i=s;i<e;i++)
		{
			*/
			return (n*s);
		//}
		
		
	}
	
	public static void main(String[] args) {
	
		
		
	}

}
