package com.nucleus.entity;

import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="Ritik1Teacher")
public class Teacher {

	@Id
	private int teacherId;
	private int teacherName;
	
	@ManyToMany
	private Set<Course> courseList;
	
	
	
	
	
	
	
	
	
	
	
	
	
	public Set<Course> getCourseList() {
		return courseList;
	}
	public void setCourseList(Set<Course> courseList) {
		this.courseList = courseList;
	}
	public int getTeacherId() {
		return teacherId;
	}
	public void setTeacherId(int teacherId) {
		this.teacherId = teacherId;
	}
	public int getTeacherName() {
		return teacherName;
	}
	public void setTeacherName(int teacherName) {
		this.teacherName = teacherName;
	}
	
	
	
	
}
