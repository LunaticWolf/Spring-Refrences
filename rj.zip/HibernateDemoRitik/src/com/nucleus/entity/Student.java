package com.nucleus.entity;


import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="Ritik1Student")
public class Student {

	@Id
	private int StudentId;
	private int StudentName;
	
	@ManyToMany
	private Set<Teacher> teacherList;
	
	@ManyToMany
	private Set<Course> courseList;
	
	public int getStudentId() {
		return StudentId;
	}
	public void setStudentId(int studentId) {
		StudentId = studentId;
	}
	public int getStudentName() {
		return StudentName;
	}
	public void setStudentName(int studentName) {
		StudentName = studentName;
	}
	
	
	
}
