package com.nucleus.entity;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="Ritik1Course")
public class Course {

	@Id
	private int courseId;

	@ManyToMany
	private Set<Teacher> teacherList;
	
	@ManyToMany
	private Set<Student> studentList;
	
	
	
	
	
	
	
	

	public Set<Student> getStudentList() {
		return studentList;
	}

	public void setStudentList(Set<Student> studentList) {
		this.studentList = studentList;
	}

	public int getCourseId() {
		return courseId;
	}

	public void setCourseId(int courseId) {
		this.courseId = courseId;
	}

	public Set<Teacher> getTeacherList() {
		return teacherList;
	}

	public void setTeacherList(Set<Teacher> teacherList) {
		this.teacherList = teacherList;
	}

	
	
	
	

}
