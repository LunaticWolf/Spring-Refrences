package com.nucleus.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.nucleus.entity.Course;
import com.nucleus.entity.Student;
import com.nucleus.entity.Teacher;

public class HibernateMain {

	public static void main(String[] args) {

		System.out.println("Hibernate Demo");
		Configuration configuration = new Configuration();
		configuration.configure();
		// configuration.configure("hibernate.cfg.xml");
		SessionFactory sfactory = configuration.buildSessionFactory();
		Session session = sfactory.openSession();
		Transaction transaction = session.beginTransaction();

		Student s1 = new Student();
		/*s1.setStudentId(studentId);
		s1.setStudentName(studentName);*/
		session.persist(s1);

		transaction.commit();
		session.close();

	}

}
