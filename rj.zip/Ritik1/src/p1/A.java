package p1;

 public class A {
static
{
	System.out.println("Parent");
}
	// int company;

    int sum(int x, int y)
    {
    	 
    	return (x+y);
    			
    }
    
   public void print(String... val)
    {
	   for(String s:val){  
		   
		   
    	System.out.println("Print from class A  is :- " + (s));
    }
    }
   
   
	
  protected void print(int p)
    {
    	System.out.println("Print from class A :- " + p);
    }

}
