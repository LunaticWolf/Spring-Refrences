// Aggregation Example :-


package p1;

public class B {
	
 static	String company="Nucleus";
	
	public static void main(String[] args) {
		
		/*String s = "WEB-INF/jsp/delete.jsp";
 		System.out.println(s+"delete.jsp");
		A A1 = new A();
		//B B1 = new B();
		//A1.company=100;
		//int d=A1.company=100;;
		int c;
		c = A1.sum(10, 20);
		A1.print(c);
	// System.out.println(d);
		A1.print(company);*/
		
		long epoch = System.currentTimeMillis()/1000;
		System.out.println("\n"+epoch);
		
		
	}

}
