package collectiondemo;

import java.util.ArrayList;
import java.util.Iterator;

class Student {
	int id;

	Student(int id) {
		this.id = id;
	}

	
	public String toString() {
		return "Student [id=" + id + "]";
	}
	
	

}

public class CollectionDemo {

	public static void main(String args[]) {

		ArrayList<Student> al = new ArrayList<Student>();

		for (int i = 1; i < 5; i++) {

			Student s = new Student(i);
			al.add(s);
		}

		Iterator<Student> itr = al.iterator();
		while (itr.hasNext()) {
			System.out.println(itr.next());
		}
	}
}
