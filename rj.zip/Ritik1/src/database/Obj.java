package database;

public class Obj {
	
	int oid;
	String oname;
	
	Obj(int id, String name)
	{
		oid=id;
		oname=name;
		
	}
	

	public static void main(String[] args) {
	
		Obj o1 =  new Obj(8,"Ganesh");
		Obj o2 =  new Obj(7,"Ramesh");
		Objdb.db(o2);
		
		//Objdb.db(o2);
		
	}

}
