package database;

public class Customer {

	int number;
	String password;
	
	Customer(int number, String password)

	{
		this.number=number;
		this.password=password;
		DataBase.db(number,password);
		
	}
	
	{                  // Init block
				
	}
	
	
	public static void main(String[] args) {
		

		Customer l1 = new Customer(1,"Lakshay");		
		Customer l2 = new Customer(2,"Lakshay");	
		
	}

}
