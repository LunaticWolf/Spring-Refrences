package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Objdb {

	public static void db(Obj o) {

		
	
//	System.out.println(o.oid);
//	System.out.println("aa");
//	System.out.println(o.oname);
//	System.out.println("ab");	
		
	try {
		
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con = DriverManager.getConnection(
				"jdbc:oracle:thin:@10.1.50.198:1521:orcl", "sh", "sh");

	
		
		PreparedStatement psmt = con
				.prepareStatement("Insert into customer3196 values (?,?)");
		psmt.setInt(1, o.oid);
		psmt.setString(2, o.oname);
		
		
		ResultSet rs = psmt.executeQuery();
		
		

	} catch (ClassNotFoundException | SQLException e) {

		e.printStackTrace();

	}

	
	
	
	
	}

}
