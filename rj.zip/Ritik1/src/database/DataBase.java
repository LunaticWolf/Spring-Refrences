package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DataBase {

	public static void db(int number , String password) {

		int count=0;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection(
					"jdbc:oracle:thin:@10.1.50.198:1521:orcl", "sh", "sh");

			PreparedStatement psmt = con
					.prepareStatement("Select * from customer3196 ");
			ResultSet rs = psmt.executeQuery();

			while (rs.next()) {
				
				if(number==rs.getInt(1) && password.equals(rs.getString(2) ))
				{
					count++;
					break;
				}
					
					
					
			//	System.out.println("Customer No." + rs.getInt(1)	+ "\n Customer Name " + rs.getString(2));
			}

		} catch (ClassNotFoundException | SQLException e) {

			e.printStackTrace();

		}

		if(count>0)
		{
			System.out.println("Valid");
		}
		else
			System.out.println("InValid");
			
	}

}
