package p2;
import p1.*;


public class Pa extends A {
	
	int x;
	
	Pa (int x)
	{
		this.x=x;
	}
	static
	{
		System.out.println("Child");
	}

	public static void main(String args[]) {
		
		//A A2 = new A();
		//A Pa1 = new Pa();\
		Pa Pa1 = new Pa(10);
		Pa Pa2 = new Pa(10);
		if(Pa1==Pa2)
		{
			System.out.println("true");
		}
		else
		{
			System.out.println("false");
		}
		
		
		System.out.println("Package P2 : Class PA_");
		Pa1.print(10);
		Pa1.print("Ritik");
		
		//System.out.p
		
		
	}
}
