package p2;

import java.util.Scanner;

public class Dv {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		int count = 0;
		System.out.println("Enter Field Name:");
		String str = sc.nextLine();

		System.out.println("Enter type:");
		String type = sc.nextLine();

		switch (type)

		{

		case "Integer":
			try {

				Integer a = new Integer(str);
				if (a.getClass().getSimpleName().equalsIgnoreCase(type)) {
					count++;
					// System.out.println("yes"+a.getClass().getSimpleName());

				}

			} catch (Exception e) {

				// System.out.println("S");
			}

			break;

		case "Float":

			try {
				Float b = new Float(str);

				if (b.getClass().getSimpleName().equalsIgnoreCase(type)) {
					count++;
					// System.out.println("yes"+a.getClass().getSimpleName());

				}

			} catch (Exception e) {

			}

			break;

		case "Double":

			try {
				Double c = new Double(str);

				if (c.getClass().getSimpleName().equalsIgnoreCase(type)) {
					count++;
					// System.out.println("yes"+a.getClass().getSimpleName());

				}

			} catch (Exception e) {

			}

		}

		if (count > 0) {
			System.out.println("YES");
		} else
			System.out.println("NO");

		// System.out.println(x.getClass().getSimpleName().equalsIgnoreCase(type));

	}

}
