package test2;


import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;


public class CombineList {


	public static List<String> combine(List<String> l1, List<String> l2)
	{
		
		List<String> l = new ArrayList<String> ();
		Iterator<String> itr1 =  l1.iterator();
		Iterator<String> itr2 =  l2.iterator();
		
		while(itr1.hasNext() || itr2.hasNext())
			{
			if(itr1.hasNext())
				l.add(itr1.next());
		
			if(itr2.hasNext())
				l.add(itr2.next());
				
			}			
		
		return   l;
		
	}

	public static void main(String[] args) {
	
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the elements of list 1");
		String s1= sc.nextLine();
		
		String[] s = s1.split("\\s");
		
	//	System.out.println("aaa");
		
		List<String> al1 = new ArrayList<String> ();
		
		for(int i=0;i<s.length;i++)
		{
			al1.add(s[i]);
		}

		////////////////////////
		
		System.out.println("Enter the elements of list 2");
		String s2= sc.nextLine();
	//	System.out.println("aaa");
		
		String[] s5 = s2.split("\\s");
		
		List<String> al2 = new ArrayList<String> ();
		
		for(int i=0;i<s5.length;i++)
		{
			al2.add(s5[i]);
		}

		
		List<String> cList = combine(al1,al2);
		cList.iterator();
		Iterator<String> itr =  cList.iterator();
		
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		
	}
	


}
