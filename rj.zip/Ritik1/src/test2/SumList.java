package test2;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class SumList {

	static int sum=0;
	
	public static void forLoop(List<Integer> al, Iterator<Integer> itr)
	{ 
		for(int i=0;i<al.size();i++)
		{
			sum=sum+itr.next();
		}
		
	}
	

	public static void whileLoop(List<Integer> al, Iterator<Integer> itr)
	{
		while(itr.hasNext())
		{
			sum=sum+itr.next();
		}
	}
	

	public static void recursion(List<Integer> al, Iterator<Integer> itr)
	{
		int size = al.size();
		
	public static void	rec()
		{
			while(size>0)
			{
				
			}
				
		}
		
		
	}
	
	
	public static void main(String[] args) {
	
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the total no. of elements ");
		int n = sc.nextInt();
		
		List<Integer> al = new ArrayList<Integer> ();
		
		System.out.println("Enter the elements ");
		for(int i=0;i<n;i++)
		{
			al.add(sc.nextInt());
		}

		Iterator<Integer> itr =  al.iterator();
		
		System.out.println("Enter the choice 1. for 2. while 3. Recursion \n");
		
		switch(sc.nextInt())
		
		{
		case 1:
			forLoop(al,itr);
			break;
			

		case 2:
			whileLoop(al,itr);
			break;
			

		case 3:
			recursion(al,itr);
			break;
		}
		
		System.out.println("\nTotal Sum   "+sum);
		
	}

}
