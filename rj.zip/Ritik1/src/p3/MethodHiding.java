package p3;

class MetroMall  
{
	int i = 10;
	
      void display()
      {
    	  System.out.println("Welcome to Metro Mall"); 
    	  
      }
      
      /////////////
      public void passObj(MetroMall M)
  	{ 
    	  Item1 L = (Item1)(M);
  		System.out.println(i);
  		L.display();
  			//System.out.println("Product: Item 2"); 
  		}
  	}
	


///////////////////////////////
class Item1   extends MetroMall
{
	int i = 20;
	void display()
    {
		
		//System.out.println("child"+i);

  	  System.out.println("Product: Item 2"); 
  	  
    }
}

//////////////////////////////////
//class Item2 extends MetroMall
//{
//	void display()
//    {
//  	  System.out.println("Product: Item 3"); 
//  	  
//    }
//}




public class MethodHiding {

	
	public static void main(String args[]) {
		
		MetroMall Mm1 = new MetroMall();
		//MethodHiding Mh1=new MethodHiding();
		MetroMall M1 = new Item1();
		Mm1.passObj(M1);
//		MetroMall M1 = new Item2();
//		Mh1.passobj(M1);
		
	}
	
	
}
