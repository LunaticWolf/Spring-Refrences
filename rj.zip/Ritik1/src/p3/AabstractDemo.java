package p3;

public abstract class AabstractDemo {

	abstract void x();

	abstract void y();

	void z() {
		System.out.println("Z");
	}

}

class Real extends AabstractDemo {

	void x() {
		System.out.println("x");

	}

	void y() {
		System.out.println("y");

	}

	public static void main(String args[]) {

		Real R = new Real();
		R.x();
		R.y();
		R.z();
	}

}
