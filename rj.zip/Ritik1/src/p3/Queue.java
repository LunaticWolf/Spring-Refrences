package p3;


public class Queue {
	
	/*Queue()
	{
		int Q[]= new int[10];
	}
	
	public void enqueue (int a)
	{
		if(Q[0]==null)
		{
			
		}
		
	}
	
	
	
	*/

	
	static boolean m (String pincode)
	{
		if (pincode.matches("[0-9]{6}")) {
			return true;

		} else {
			return false;
		}
		
	}
	
	
	
	public static void main(String args[])
	{
		
		boolean b = m("445554444");
		System.out.println(b);
		
	}









	
}
