package p3;

// Object Restriction Example

public class Main {       // Main Class for which we have to restrict
 
	private static Main M1;         

	private Main() {

	}

	int sum(int x, int y) {

		return (x + y);

	}

	public void print(String str) {
		System.out.println("Print from Main class   is :- " + str);
	}

	protected void print(int p) {
		System.out.println("Print from Main class A :- " + p);
	}

	public static Main createObjct()

	{

		if (M1 == null) {    //object verification

			System.out.println("New object created");
			M1 = new Main();    // creation of object
			return M1;           // reference return 
		} else {
			System.out.println("Object already exist, please use this");
			return M1;              // reference return
		}

	}

}

class Secondry {        // Secondry class from where we are requesting
	public static void main(String args[]) {

		Main S;
	//	Main.createObjct(); 
		S = Main.createObjct();      //request of object
		S.print(10);
		S.print("Ritik");
		S = Main.createObjct();
		S.print("Rahul");

	}

}
