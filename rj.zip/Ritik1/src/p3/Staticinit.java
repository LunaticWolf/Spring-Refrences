package p3;

public class Staticinit {

	int sroll;
	String sname;
	String sgender;
	static String scompany;
    static int count=0;
    
	static {
		scompany = "Nucleus";
	}
	
		Staticinit(String sname, int sroll, String sgender) {
		this.sname = sname;
		this.sroll = sroll;
		this.sgender = sgender;
		
	}

	public void display() {             // Display method
		System.out.println(scompany+" Nsbt " + sname + " " + sroll );
	}

	{ // Instance initializer block
	    count++;
		System.out.println("Welcome to " + scompany + " \n Student No. "+ count);
	}
	

		public static void main(String[] args) {           

		Staticinit S1 = new Staticinit("Ritik", 35, "M");       // Object 1
		S1.display();
		Staticinit S2 = new Staticinit("Rahul", 45, "M");       // Object 2
		S2.display();
	}

}
