package p3;

public class Array {  

	static void display(int arr[]){  
	
		
		for(int i=0;i<arr.length;i++)  
		 	System.out.println(arr[i]);  
		}  
		  
		public static void main(String args[]){  
		  
		int a[]={33,3,4,5};  
		display(a);//passing array to method  
		  
		}
		
}  

