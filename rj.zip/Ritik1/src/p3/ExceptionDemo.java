package p3;
import java.io.*;

class Parent   
{
	/*void msg() 
	{
		System.out.println("parent");  
	} 
 */
}

// throws IOException	
class Child extends Parent
	{  
	  void msg() throws ArithmeticException
	  {
		  System.out.println("TestExceptionChild");  
	  }  
	    
	  }  
	

public class ExceptionDemo {	 
	
public static void main(String args[]){  
	Child c = new Child();   
	Parent p=new Child();  
//	 Child c1 = 
			 ((Child)p).msg();
	//   p.msg();
	   /*  try {
		p.msg();
	} catch (IOException e) {
			e.printStackTrace();
	}  */
	  
	
	
}
}
