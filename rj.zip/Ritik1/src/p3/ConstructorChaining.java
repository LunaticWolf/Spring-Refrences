package p3;

public class ConstructorChaining {

	int a;
	int b;
	int c;
	
	ConstructorChaining()
	{
	System.out.println("No argument constructor");	
	}
	
	ConstructorChaining(int a)
	{
		this(a,0);
	}
	
	ConstructorChaining(int a, int b)
	{
		this(a,b,0);
	}
	
	ConstructorChaining(int a, int b, int c)
	{
		System.out.println(a+" "+b+" "+c);
	}
	
	public static void main(String[] args) {
		
		
		ConstructorChaining C1= new ConstructorChaining();
		ConstructorChaining C2= new ConstructorChaining(10);
		ConstructorChaining C3= new ConstructorChaining(10,20);
		ConstructorChaining C4= new ConstructorChaining(10,20,30);
		
		
	}

}
