package test;

import java.util.Scanner;

public class Test3 {

	static int count = 0;

	public static void attempt(int j, int d, int n, int arr) {
		int m = arr;

		if (j >= m) {

			count++;
		} else {

			int x = (m - j) + d;

			count++;

			attempt(j, d, n, x);

		}

	}

	// ///////////////////
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Jumping Capacity");
		int jump = sc.nextInt();

		System.out.println("Enter the Slide Down Factor");
		int down = sc.nextInt();

		System.out.println("Enter the total no. of walls");
		int n = sc.nextInt();

		int walls[] = new int[n];

		System.out.println("Enter the Height of walls");
		for (int i = 0; i < n; i++) {
			System.out.println("Wall Height " + (i + 1));
			int a = sc.nextInt();
			walls[i] = a;
		}

		for (int i = 0; i < n; i++)

		{
			attempt(jump, down, n, walls[i]);
		}

		System.out.println("Total Attempt :- " + count);
	}

}
