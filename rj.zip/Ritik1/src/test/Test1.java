package test;


public class Test1 {

	
	
	public static void main(String[] args) {
		
		int arr[]={1,2,3,4,5,6,7,8,9};
		
		String [] s={"+","-",""};
		
		String s1 = "1+2+3+4";
/*		
 * int i= (int)s1;*/
		System.out.println(s1);
		int x = arr[0]+arr[1];
		System.out.println(x);

	}

}
