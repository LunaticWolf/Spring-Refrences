package clonabledemo;



class Student implements Cloneable  {
	int sid;
	String sname;

	public Student(int sid, String sname) {

		this.sid = sid;
		this.sname = sname;
	}
	
	
	public Object clone()throws CloneNotSupportedException{  
		return super.clone();  
		}


	@Override
	public String toString() {
		return "Student [sid=" + sid + ", sname=" + sname + "]";
	}  
	
	
	

}



public class ClonableDemo {
	

	public static void main(String[] args) {
	
		Student s = new Student(1,"Ritik");
		System.out.println(s);
		try {
			Student s2=(Student)s.clone();
			System.out.println(s2);
			s2.sid=50;
			
			System.out.println("After change"+s2);
			System.out.println(s);
			if(s==s2)
			{
				System.out.println("Equal");
			}else
				System.out.println("Not equal");
				
		} catch (CloneNotSupportedException e) {
			
			e.printStackTrace();
		}  
		

	}

}
