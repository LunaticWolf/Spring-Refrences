package databasedemo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CustomerDAO {

	public static Customer save(Customer C) throws SQLException {
		Connection conn;
		conn = ConnectionClass.getConnection();
		Customer c1 = C;

		PreparedStatement psmt = conn
				.prepareStatement("Select * from customer65");

		ResultSet rs = psmt.executeQuery();

		while (rs.next()) {

		//	c1 = new Customer();
			c1.setCid(rs.getInt(1));
			c1.setCname(rs.getString(2));

		}

		return c1;
	}

}
