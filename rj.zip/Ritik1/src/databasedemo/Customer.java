package databasedemo;

import java.sql.SQLException;

public class Customer {

	private int cid;
	private String cname;
	
	///////////////////////////////////////////////////
	public int getCid() {
		return cid;
	}

	public void setCid(int cid) {
		this.cid = cid;
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}
	
	public void display()
	{
		System.out.println("Customer ID: "+cid+"\nCustomer Name "+cname);
	}
	
	///////////////////////////////////////////////////
	
}
