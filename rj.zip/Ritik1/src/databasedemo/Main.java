package databasedemo;

import java.sql.SQLException;

public class Main {

	public static void main(String[] args) {
		
		Customer customer = new Customer();
		try {
		customer =	CustomerDAO.save(customer);
		customer.display();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
	//	c.display();
		
	}

}
