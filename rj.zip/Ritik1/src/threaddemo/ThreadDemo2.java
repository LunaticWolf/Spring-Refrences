package threaddemo;


class Student
{
int id;

public void display()
{for (int i = 1; i < 11; i++) {

System.out.println(i);	
}
}
}


class TestSleep implements Runnable {
	public void run() {
		
			try {
				System.out.println("Thread executing");
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				System.out.println(e);
			}
			
		

	}

}

public class ThreadDemo2 {

	public static void main(String args[]) {

		TestSleep t1 = new TestSleep();
		TestSleep t2 = new TestSleep();

		Thread th = new 
		t1.start();
		t2.start();
	}

}
