package threaddemo;

///////////////// Object lock

class MyThread1 implements Runnable {

	public void run() {
		System.out.println("Thread is running...");
		for(int i =0; i < 10;i++)
		{
			System.out.println(i);
			//mt1.sleep(10000);
		}
		
	}

}

public class ThreadDemo {

	public static void main(String args[]) {
		ThreadDemo m1 = new ThreadDemo();
		MyThread1 mt1 = new MyThread1();
		Thread t1 = new Thread(mt1);
		t1.start();
		try {
			t1.sleep(10000);
		//	t1.join();
		} catch (InterruptedException e) {
						
		}

		
		
		MyThread1 mt2 = new MyThread1();
		Thread t2 = new Thread(mt2);
		t2.start();
		t1.interrupt();
	}
}
