
public class Test {

	 int Roll;
	 String Name;
	 static String company= "Nucleus";
	 
	 
	public static void main(String[] args) {
		
		System.out.println("Ritik");
         Test t1 = new Test();  //creation of object 
        	t1.Roll= 45;   
            t1.Name="ritik";
            
         System.out.println("Roll No. "+ t1.Roll + "\n" + "Name " + t1.Name + "\n" +company );
         
         long epoch = System.currentTimeMillis()/1000;
 		System.out.println("\n"+epoch);
	}

}
