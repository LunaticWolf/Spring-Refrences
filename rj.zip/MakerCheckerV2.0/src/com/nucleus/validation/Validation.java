package com.nucleus.validation;

import java.util.Iterator;
import java.util.List;

import com.nucleus.model.Customer;
import com.nucleus.model.UserDetails;
import com.nucleus.service.IUserDetailsService;
import com.nucleus.service.UserDetailsServiceImpl;

public class Validation {

	

	public UserDetails isLoginExist(UserDetails userDetails)
	
	{
		
	//UserDetailsDAO udo = new UserDetailsDAO();
	
	IUserDetailsService iUserDetailsService = new UserDetailsServiceImpl();
	
	
	return	 (iUserDetailsService.isLoginExist(userDetails));
	 
	
	}//end of login verify
	
	
	
	public boolean isValidName(String name) {
		
	 	if(name.matches("[a-zA-Z0-9 ]{1,30}"))
		{
			return true;
		} else {
			System.out.println("Name voilated");
			return false;
		
		}
			}
		
		
		public boolean	isValidAddress1(String add)
		{
			add.trim();
			if(add.length()==0)
			{
			//String a = add.trim();
//			if(a==null)
//			{
			System.out.println("Invalid Address :- null");
				return false;
			}
					
			else
			{
				return true;
		}
		}

		/*public boolean isValidCustomer_code(String Customer_code, List l) {

			String code = Customer_code;
			  Iterator itr=l.iterator();  
			  int count=0;
			  while(itr.hasNext())
			  {  
				 Customer c= (Customer) itr.next();
				 
			  // System.out.println(itr.next());  
				int x = code.compareTo(c.getCustomer_code());
			   
			if(x==0)
				{
				count++;
				//System.out.println("Contains");
			//	return false;
				}
			else
			{
				//System.out.println("Not Contains");
				//return true;
				}
			  }
			  if (count > 0 ||code.length()>10 )
			 	{		System.out.println("Duplicate or Invalid Size ");
					return false;
			}
					else 
						{
						return true;
						}

			  }
*/
		public boolean isValidPincode(String pincode) {

			if (pincode.matches("[0-9]{6}")) {
				return true;

			} else {
				System.out.println("Pincode voilated");
				return false;
			}
		}

		public boolean isvalidEmail(String email) {
			

			if (email.matches("^[a-zA-Z0-9.a-zA-Z0-9_a-zA-Z0-9]{1,20}@[a-zA-Z0-9]{1,20}.[.a-zA-Z]{1,6}$"))
							return true;
			else
			{ System.out.println("Invalid email.");
				return false;
			}	
		}

		public boolean isValidRecordStatus(String recordstatus) {
			
			if(recordstatus.matches("[NMDR]"))
			{
			return true;
			} 
			else {
				System.out.println("No Record Status match found.");
				return true;
			}
		}

		
		public boolean isValidActiveinActiveflag(String activeinactiveflag) {
			if (activeinactiveflag.matches("[AI]")) {
				return true;

			} else {
				System.out.println("No Flag match found.");
				return true;
			}
		}
	
	
	
}

	
