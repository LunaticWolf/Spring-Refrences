package com.nucleus.service;

import com.nucleus.model.UserDetails;

public interface IUserDetailsService {

	
	public UserDetails isLoginExist(UserDetails userDetails);
	
	public int userRegister(UserDetails userDetails);
	
}
