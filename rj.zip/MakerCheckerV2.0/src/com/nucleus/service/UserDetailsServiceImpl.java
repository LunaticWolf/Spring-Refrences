package com.nucleus.service;

import com.nucleus.dao.IUserDetailsDAO;
import com.nucleus.dao.UserDetailsDAOImpl;
import com.nucleus.model.UserDetails;

public class UserDetailsServiceImpl implements IUserDetailsService {

	
	
	
	@Override
	public UserDetails isLoginExist(UserDetails userDetails) {
		
		IUserDetailsDAO iUserDetailsDAO = new UserDetailsDAOImpl();
		return	(iUserDetailsDAO.isLoginExist(userDetails));
		
		
	}

	@Override
	public int userRegister(UserDetails userDetails) {
	
		IUserDetailsDAO iUserDetailsDAO = new UserDetailsDAOImpl();
		return	(iUserDetailsDAO.userRegister(userDetails));
	}

	

	
}
