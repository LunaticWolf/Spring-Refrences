package com.nucleus.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.nucleus.listner.ActiveUser;


@WebFilter("/LoginFilter")
public class LoginFilter implements Filter {

    
    public LoginFilter() {
        // TODO Auto-generated constructor stub
    }

	
	public void destroy() {
		
	}

	
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		
		
		
		
		HttpServletRequest req = (HttpServletRequest)request;
	    HttpServletResponse resp = (HttpServletResponse)response;
		System.out.println("Filter working");
		
		
		resp.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
        resp.setHeader("Pragma", "no-cache"); // HTTP 1.0.
        resp.setDateHeader("Expires", 0); 
		
		HttpSession session = req.getSession(false);
		String userName=(String)session.getAttribute("userName");
		ActiveUser activeUser=(ActiveUser)session.getAttribute("activeUser");
System.out.println(userName+"checking existence of user from filter");
System.out.println(activeUser+"checking existence of user from filter");
		System.out.println(session);
		if (session == null || activeUser==null || activeUser.getActiveUser() ==null ) 
		{
			//out.print("Please login first");
			//request.getRequestDispatcher("login.jsp").include(request, response);
			resp.sendRedirect("login.jsp");
		}// end of session verification
		else{
			System.out.println("Filter working Session true");
		chain.doFilter(request, response);
		
		//////////////////////////
		resp.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
		resp.setHeader("Pragma", "no-cache"); // HTTP 1.0.
		resp.setDateHeader("Expires", 0); // Proxies.
	}
	}
	
	public void init(FilterConfig fConfig) throws ServletException {
		
	}

}
