package com.nucleus.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;





import org.apache.log4j.Logger;

import com.nucleus.listner.ActiveUser;
import com.nucleus.listner.ActiveUser5;
import com.nucleus.model.UserDetails;
import com.nucleus.service.IUserDetailsService;
import com.nucleus.service.UserDetailsServiceImpl;
import com.nucleus.validation.Validation;


@WebServlet("/Main")

public class MainController extends HttpServlet {

	final static Logger logger = Logger.getLogger(com.nucleus.controller.MainController.class);
	
	
	private static final long serialVersionUID = 1L;

	protected void doProcessing(HttpServletRequest request,	HttpServletResponse response) throws ServletException, IOException {

		logger.debug("success");
		
		PrintWriter pw = response.getWriter();
		response.setContentType("text/html");
		
		String action = request.getParameter("action");
		
		if(action!=null)
		{
		
		if(action.equalsIgnoreCase("Logout"))
		{
			response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
	        response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
	        response.setDateHeader("Expires", 0); 
	        
			HttpSession session=request.getSession(false);  
			
			session.removeAttribute("userName");
			session.removeAttribute("activeUser");
//            session.invalidate();  
            
            System.out.println(session);
            request.setAttribute("errorMessage",
					"Login");
		
            System.out.println("session logout");
            pw.print("You are successfully logged out!");  
            request.setAttribute("errorMessage", "You are successfully logged out!");
			request.getRequestDispatcher("login.jsp").forward(request,
					response);
            
		}// end of logout
		
		else{
		
		String userName = request.getParameter("userName");
		String userPassword = request.getParameter("userPassword");
		System.out.println(userName+"form i/o");
		UserDetails userDetails = new UserDetails();
		userDetails.setUserName(userName);
		userDetails.setUserPassword(userPassword);
		
		Validation v = new Validation();
		
/////////////////////////////////////////////////////////////////
		
		if (action.equalsIgnoreCase("Login")) {	
			
			UserDetails userDetails1 = v.isLoginExist(userDetails);

			if(userDetails1.getUserRole().equalsIgnoreCase("a")){
				System.out.println("invalid credentials");
				request.setAttribute("errorMessage",
						"Please Enter Valid details");
				request.getRequestDispatcher("login.jsp").forward(request,
						response);
				
			}
			
			else	if (userDetails1.getUserRole() != null) {// valid user
				
			/*String cuserName = (String)getServletContext().getAttribute(userName);
					
			if(cuserName!=null && userDetails1.getUserName().equals(cuserName) )
			{
				response.sendRedirect("checker.jsp");  
			}*/
				
			
			
				HttpSession session=request.getSession();  // Session Generated
		       ActiveUser activeUser = new ActiveUser();
			//	ActiveUser1 activeUser = new ActiveUser1()
		    //   ActiveUser5 activeUser = new ActiveUser5();
		       
		       	activeUser.setActiveUser(userName);
				session.setAttribute("activeUser",activeUser);
				session.setAttribute("userName",userName);  
		        
				
				if(activeUser.alreadyLoggedIn)
				{
					
			        	pw.println("Already login"); 
			        	System.out.println("Already login p");
			       
				}
				
				
				else 
		        {
		       String[] remember= request.getParameterValues("remember");
		        if(remember==null || remember.length!=0) 
		        { 
		        	System.out.println("remember me");
		        Cookie c = new Cookie("userName", userName); 
		        c.setMaxAge(24*60*60); 
		        response.addCookie(c); // cookie added
		        }else
		        {
		        	System.out.println("no remember");
		        }
		        
		        
		        
		        ServletContext sc = getServletContext();// application
		       // sc.setAttribute(arg0, arg1);
		        sc.setAttribute("userName", userName);
				
				if(userDetails1.getUserRole().equalsIgnoreCase("maker"))
				{
					//System.out.println();
					RequestDispatcher rd = request
							.getRequestDispatcher("WEB-INF/jsp/maker.jsp");
					rd.forward(request, response);
			//	response.sendRedirect("WEB-INF/maker.jsp");  
				}
				else if(userDetails1.getUserRole().equalsIgnoreCase("checker"))
				{
					response.sendRedirect("checker.jsp");
				}
				/*RequestDispatcher rd = request.getRequestDispatcher("Servlet2");
				rd.forward(request, response);*/
				
		        }//end of else of listner check
		        
				
				
			}// valid user 
			/*else if(userDetails1.getUserRole() == null){
				System.out.println("invalid credentials");
			}
			else {
				System.out.println("invalid credentials");
				request.setAttribute("errorMessage",
						"Please Enter Valid details");
				request.getRequestDispatcher("login.jsp").forward(request,
						response);

			}//invalid user else

*/		
			} // end of if login
		
		else if (action.equalsIgnoreCase("Register")) 
		{
			String userRole = request.getParameter("userRole");
			
			UserDetails userDetails1 = v.isLoginExist(userDetails);

			if (userDetails1.getUserRole().equalsIgnoreCase(userRole)) {
				
				request.setAttribute("errorMessage",
						"Already Registered");
			request.getRequestDispatcher("register.jsp").forward(request,response);

				/*RequestDispatcher rd = request.getRequestDispatcher("Servlet2");
				rd.forward(request, response);*/
			} // end of already register
			else if(userDetails1.getUserRole() != null) // new register
			{
				userDetails1.setUserRole(userRole); 
			
				if(v.isValidName(userPassword))
				{
					IUserDetailsService iUserDetailsService = new UserDetailsServiceImpl();
					
				int i =	iUserDetailsService.userRegister(userDetails1);
					 //udo.UserDetailsDbOperationSave(userDetails);
					if(i!=0)
					{		
					request.setAttribute("errorMessage",
						"Successfully registered");
					
					
				request.getRequestDispatcher("login.jsp").forward(request,
						response);
					}
					else
					{
						request.setAttribute("errorMessage",
								"Error in registering");
						request.getRequestDispatcher("login.jsp").forward(request,
								response);
					}
//				pw.println("<br>"+userId+userPassword+userRole);
				//response.sendRedirect("login.jsp");  
		
				}
				}
			
			
			
			
		}//end of register
		
		
		
		}//end of else of logout
		
		}// action null
		
		else
		{
			request.getRequestDispatcher("login.jsp").forward(request,
					response);
		}

	}// end of do

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doProcessing(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doProcessing(request, response);
	}

}
