package com.nucleus.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.nucleus.connection.ConnectionClass;
import com.nucleus.model.UserDetails;

public class UserDetailsDAOImpl implements IUserDetailsDAO {

	@Override
	public UserDetails isLoginExist(UserDetails userDetails) {
		Connection conn=null;
		try{
			System.out.println(userDetails.getUserName()+"Valid i/o");
		conn = ConnectionClass.getConnection();
			PreparedStatement psmt = conn
					.prepareStatement("Select * from UserDetailsLogin where userName=? AND UserPassword=?");
			
			psmt.setString(1, userDetails.getUserName());
			psmt.setString(2, userDetails.getUserPassword());
			System.out.println(userDetails.getUserName()+"1Valid i/o");
			
			ResultSet rs = psmt.executeQuery();

			if (rs.next()) {
				System.out.println("record exist db");
			userDetails.setUserRole(rs.getString(3));  
			
			}else
			{System.out.println("No record exist");
				userDetails.setUserRole("a");
			}

		} catch (SQLException e) {

			e.printStackTrace();

		}
		finally{
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return userDetails;
	}// end of isLoginExist method
/////////////////////////////////////////////////////////////////////////////////////////
	
	public int userRegister(UserDetails userDetails) {
		int i=0;
		Connection conn=null;
		
		conn = ConnectionClass.getConnection();
			PreparedStatement psmt;
			try {
				psmt = conn
						.prepareStatement("insert into UserDetailsLogin values (?,?,?)");
				
	psmt.setString(1,userDetails.getUserName());
	psmt.setString(2, userDetails.getUserPassword());
	psmt.setString(3, userDetails.getUserRole());

		i=psmt.executeUpdate();
		System.out.println("Success Login Registered");
			} catch (SQLException e) {

				e.printStackTrace();
			}
		
		finally
		{
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
			return i;
	}// end of register method
	
	
	
}// end of class
