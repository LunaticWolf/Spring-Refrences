package com.nucleus.dao;

import java.util.List;

import com.nucleus.model.Customer;

public class CustomerDAOXmlImpl implements ICustomerDAO{

	@Override
	public int addUser(Customer customer) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deleteUser(Customer customer) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Customer ViewUserById(Customer customer) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Customer> viewUsers(String orderby, String order) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Customer> viewUsers() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int updateByCode(Customer customer) {
		// TODO Auto-generated method stub
		return 0;
	}

	
	
	
}
