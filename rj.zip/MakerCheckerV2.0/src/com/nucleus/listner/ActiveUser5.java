package com.nucleus.listner;


import java.util.HashMap;

import java.util.Map;




import javax.servlet.http.HttpSession;
//import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpSessionBindingEvent;
import javax.servlet.http.HttpSessionBindingListener;

//@WebListener
public class ActiveUser5 implements HttpSessionBindingListener{

	private String activeUser;	  
	private static Map<ActiveUser5,  HttpSession > logins = new HashMap<ActiveUser5,  HttpSession> ();
	
	//////////////////////////////////////////
	public String getActiveUser() {
		return activeUser;
	}

	public void setActiveUser(String activeUser) {
		this.activeUser = activeUser;
	}

	/////////////////////////////////////////
	
	
	
	
	
	@Override
	public void valueBound(HttpSessionBindingEvent event) {
		System.out.println("kuch chlra hai");
		HttpSession session = logins.remove(this);
		
		if(session !=null)
		{
			session.invalidate();
		}
		logins.put(this, event.getSession());
		
	
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((activeUser == null) ? 0 : activeUser.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ActiveUser5 other = (ActiveUser5) obj;
		if (activeUser == null) {
			if (other.activeUser != null)
				return false;
		} else if (!activeUser.equals(other.activeUser))
			return false;
		return true;
	}

	@Override
	public void valueUnbound(HttpSessionBindingEvent e) {
		
		logins.remove(this);
		
	}

	
	
	
}
