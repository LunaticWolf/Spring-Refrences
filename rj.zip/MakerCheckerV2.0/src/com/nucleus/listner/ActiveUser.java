package com.nucleus.listner;

import java.util.ArrayList;
import java.util.List;

//import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpSessionBindingEvent;
import javax.servlet.http.HttpSessionBindingListener;

//@WebListener
public class ActiveUser implements HttpSessionBindingListener{

	private String activeUser;
	  public boolean alreadyLoggedIn;
	  
	private static List<String> activeUserList; 
	
	//////////////////////////////////////////
	public String getActiveUser() {
		return activeUser;
	}

	public void setActiveUser(String activeUser) {
		this.activeUser = activeUser;
	}

	/////////////////////////////////////////
	
	@Override
	public void valueBound(HttpSessionBindingEvent e) {
		
		alreadyLoggedIn=true;
		//List<String> activeUserList = null; 
		System.out.println(e.getValue()+"    listner ");
		ActiveUser activeUser = (ActiveUser)e.getValue();
		//ActiveUser activeUser = (ActiveUser)e.getSession().getAttribute("activeUser");
		
		System.out.println(activeUserList+"  exist_list");
		
		System.out.println("Session attribute set");
	//	System.out.println("activeuser "+ activeUser);
		System.out.println("activeuser coming for verification "+ activeUser.getActiveUser());
		
		if(activeUserList==null)
		{
			
			System.out.println("first active user");
			activeUserList = new ArrayList<String>();
			activeUserList.add(activeUser.getActiveUser());
			alreadyLoggedIn=false;
			System.out.println("added active user");
		}
		
		else if(activeUserList.contains(activeUser.getActiveUser()))
		{
			System.out.println("already active");
			alreadyLoggedIn=true;
		}
		else
		{
			System.out.println("first! active user");
			activeUserList.add(activeUser.getActiveUser());
			System.out.println("added active user");
			alreadyLoggedIn=false;
		}
		
	
	}

	@Override
	public void valueUnbound(HttpSessionBindingEvent e) {
		
//	String userName = 	(String)e.getSession().getAttribute("userName");
	ActiveUser activeUser = (ActiveUser)e.getValue();
		System.out.println("Inactive "+ this.activeUser);
		System.out.println("Inactive user name "+ activeUser.getActiveUser());
//		activeUserList.remove("activeUser.getActiveUser()");
		activeUserList.remove(activeUser.getActiveUser());
	}

	
	
	
}
