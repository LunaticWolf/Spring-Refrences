package com.hibernatedemo.p3.entity;

//import javax.persistence.Embeddable;

//import javax.persistence.Embeddable;
import javax.persistence.Id;
//import javax.persistence.Table;





//@Embeddable
//@Table(name="RStudent")
public class Address {

//	@Id
	private int pincode;
	private String city;
	private String area;
	
	
	public int getPincode() {
		return pincode;
	}
	public void setPincode(int pincode) {
		this.pincode = pincode;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	
	
}
