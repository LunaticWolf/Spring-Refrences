package com.hibernatedemo.p3.entity;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;

public class GeneralSequenceNumber {

	
	@Id
	  @GeneratedValue
	  private Long number;
	
}
