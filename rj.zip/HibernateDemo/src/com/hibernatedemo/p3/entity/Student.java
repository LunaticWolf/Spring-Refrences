package com.hibernatedemo.p3.entity;

//import java.util.List;


import javax.annotation.Generated;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.TableGenerator;




@Entity
@Table(name="RStudent")
public class Student {

	@Id
	private int stdId;  
	
	//@Generated(value = { "id" })
	/*@TableGenerator(strategy= GenerationType.SEQUENCE
		    name="orderGenerator",
		    table="GENERATOR_TABLE",
		    pkColumnName = "key",
		    valueColumnName = "next",
		    pkColumnValue="order_number",
		    allocationSize=30)*/
	 @OneToOne
	  private GeneralSequenceNumber number;
	//private int id;  
	private String stdName;  
	
	@Embedded
	private Address address;   
	
	@Embedded
	
	@AttributeOverrides({ 
	 @AttributeOverride(name="pincode"  , column=@Column(name="temp_pin")), 
	 @AttributeOverride(name="area"  , column=@Column(name="temp_area")), 
	 @AttributeOverride(name="city"  , column=@Column(name="temp_city")) 
	})
	
	private Address tempAddress;   
	
	public int getStdId() {
		return stdId;
	}
	public void setStdId(int stdId) {
		this.stdId = stdId;
	}
	
	/*public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}*/
	
	public String getStdName() {
		return stdName;
	}
	public void setStdName(String stdName) {
		this.stdName = stdName;
	}
	public Address getTempAddress() {
		return tempAddress;
	}
	public void setTempAddress(Address tempAddress) {
		this.tempAddress = tempAddress;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	
	
}
