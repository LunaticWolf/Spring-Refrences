package com.hibernatedemo.p3.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.hibernatedemo.p3.entity.Address;
import com.hibernatedemo.p3.entity.Student;



public class CollectionHibernateDemo {

	public static void main(String[] args) {

		System.out.println("Hibernate Demo");
		Configuration configuration = new Configuration();
		configuration.configure();
		// configuration.configure("hibernate.cfg.xml");
		SessionFactory sfactory = configuration.buildSessionFactory();
		Session session = sfactory.openSession();
		Transaction transaction = session.beginTransaction();

		Address address = new Address();
		Student s1 = new Student();
		
		s1.setStdId(9);
		//s1.setId(id);
		s1.setStdName("Raaajat");
		
		address.setPincode(110032);
		address.setArea("Shahdara");
		address.setCity("Delhi");
		
		s1.setAddress(address);
		
		Address address2 = new Address();
		
		address2.setPincode(110059);
		address2.setArea("Ghaziabad");
		address2.setCity("UP");
		
		s1.setTempAddress(address2);
		
		//session.persist(address);
		session.persist(s1);
		
		////////////////////////////////////////////////////////////////////////////////
		/*Address address2 = new Address();
		Student s2 = new Student();
		
		s2.setStdId(2);
		s2.setStdName("Rahul");
		
		address2.setPincode(110032);
		address2.setArea("Shahdara");
		address2.setCity("Delhi");
		
		s2.setTempAddress(address2);
		//session.persist(address);
		session.persist(s2);
		*/

		/*Student s = (Student) session.get(Student.class, 5);
		System.out.println(s);
*/
		transaction.commit();
		session.close();

	}

}
