package com.hibernatedemo.p1;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table(name="RJStudent")
public class Student {
@Id
		private int stdId;  
		private String stdFirstName;
		private String stdLastName;
		private String address;
	

		public int getStdId() {
			return stdId;
		}
		public void setStdId(int stdId) {
			this.stdId = stdId;
		}
		public String getStdFirstName() {
			return stdFirstName;
		}
		public void setStdFirstName(String stdFirstName) {
			this.stdFirstName = stdFirstName;
		}
		public String getStdLastName() {
			return stdLastName;
		}
		public void setStdLastName(String stdLastName) {
			this.stdLastName = stdLastName;
		}
		public String getAddress() {
			return address;
		}
		public void setAddress(String address) {
			this.address = address;
		}
		
		@Override
		public String toString() {
			return "Student [stdId=" + stdId + ", stdFirstName=" + stdFirstName
					+ ", stdLastName=" + stdLastName + ", address=" + address + "]";
		}

		
		
}
