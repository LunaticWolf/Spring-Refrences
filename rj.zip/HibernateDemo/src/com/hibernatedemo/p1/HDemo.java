package com.hibernatedemo.p1;



import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class HDemo {
		

		public static void main(String[] args) {
			Configuration configuration=new Configuration();
			configuration.configure();
			//configuration.configure("hibernate.cfg.xml");  
			SessionFactory sfactory=configuration.buildSessionFactory();
			Session session= sfactory.openSession();
			Transaction transaction=session.beginTransaction();
		
			
			
			Student s1=new Student();
			s1.setStdId(5);
			s1.setStdFirstName("Rajat");
			s1.setStdLastName("Singh");
			s1.setAddress("2901");
		
			session.persist(s1);
			
		Student s =	(Student)session.get(Student.class, 5);
			System.out.println(s);
			
			transaction.commit();
			session.close();
			
			
			

		}


	}


