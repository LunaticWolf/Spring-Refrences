package com.hibaernatedemo.p2.entity;

public class Pen {
	
	private int pid;
	private String pname;
	
	
	

}
