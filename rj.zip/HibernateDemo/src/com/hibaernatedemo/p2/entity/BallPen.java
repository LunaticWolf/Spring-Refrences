package com.hibaernatedemo.p2.entity;

public class BallPen {

	private int pcost;
	
	
}
