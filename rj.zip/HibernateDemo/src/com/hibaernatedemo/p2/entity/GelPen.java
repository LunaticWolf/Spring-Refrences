package com.hibaernatedemo.p2.entity;

public class GelPen {

	private int pcost;
	
	
}
