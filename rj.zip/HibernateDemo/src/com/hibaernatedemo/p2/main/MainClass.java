package com.hibaernatedemo.p2.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.hibaernatedemo.p2.entity.BallPen;
import com.hibaernatedemo.p2.entity.GelPen;
import com.hibaernatedemo.p2.entity.Pen;
import com.hibernatedemo.p1.Student;

public class MainClass {

	
	public static void main(String[] args) {
		
		Configuration configuration=new Configuration();
		configuration.configure();
		//configuration.configure("hibernate.cfg.xml");  
		SessionFactory sfactory=configuration.buildSessionFactory();
		Session session= sfactory.openSession();
		Transaction transaction=session.beginTransaction();
	
		Pen p = new Pen();
		
		
		BallPen bp = new BallPen();
		
		
		GelPen gp = new GelPen();
		

	
		session.persist(p);
		session.persist(bp);
		session.persist(gp);
//	Student s =	(Student)session.get(Student.class, 5);
	//	System.out.println(s);
		
		transaction.commit();
		session.close();
		
		
	}

}
