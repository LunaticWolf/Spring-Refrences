package com.nucleus;


import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class App 
{
    public static void main( String[] args )
    {
      ApplicationContext context=new ClassPathXmlApplicationContext("springconfig1.xml");
    /*Customer c1=(Customer)context.getBean("c1");
    System.out.println(c1.getCustid()+" "+c1.getCustname());
    Customer c3=(Customer)context.getBean("c3");
    System.out.println(c3.getCustid()+" "+c3.getCustname());
    */
     /*Customer c2=(Customer)context.getBean("c2");
    System.out.println(c2.getCustid()+" "+c2.getCustname());
    Customer c02=(Customer)context.getBean("c2");
    System.out.println(c2.getCustid()+" "+c2.getCustname());
   System.out.println(c2==c02);*/

      
     /* Address adr=(Address)context.getBean("adr1");
      System.out.println(adr.getCountry()+" "+adr.getCity());
      System.out.println(adr.getLandmark().get(0));
      System.out.println(adr.getLandmark().get(1));*/
      
      /*Customer c2=(Customer)context.getBean("c2");
      System.out.println(c2.getCustid()+" "+c2.getCustname()+" "+c2.getAdr().getCountry());*/
      Customer c2=(Customer)context.getBean("c2");
      
      System.out.println(c2.getCustid()+" "+c2.getCustname());
      List<Address> adrList=c2.getAdrList();
      System.out.println(adrList.getClass().getSimpleName());
      for(Address a:adrList)
      {
    	  System.out.println(a.getCountry()+" "+a.getCity()+" "+a.getLandmark().get(0));
      }
    }
}
