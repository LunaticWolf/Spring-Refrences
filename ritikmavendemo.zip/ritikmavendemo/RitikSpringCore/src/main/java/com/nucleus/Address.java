package com.nucleus;

import java.util.List;

public class Address 
{
private String city;
private String country;
private List<String> landmark;

public List<String> getLandmark() {
	return landmark;
}
public void setLandmark(List<String> landmark) {
	this.landmark = landmark;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public String getCountry() {
	return country;
}
public void setCountry(String country) {
	this.country = country;
}

}
