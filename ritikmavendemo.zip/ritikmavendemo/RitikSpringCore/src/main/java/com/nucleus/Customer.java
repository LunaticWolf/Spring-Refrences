package com.nucleus;

import java.util.List;

public class Customer 
{
private int custid;
private String custname;
private List<Address> adrList;


public List<Address> getAdrList() {
	return adrList;
}
public void setAdrList(List<Address> adrList) {
	this.adrList = adrList;
}
/*private Address adr;

public Address getAdr() {
	return adr;
}
public void setAdr(Address adr) {
	this.adr = adr;
}*/
public Customer() {	
	System.out.println("No Arg Constructor Invoked");
}
public Customer(int custid, String custname) {	
	this.custid = custid;
	this.custname = custname;
}
public int getCustid() {
	return custid;
}
public void setCustid(int custid) {
	this.custid = custid;
}
public String getCustname() {
	return custname;
}
public void setCustname(String custname) {
	this.custname = custname;
}

}
