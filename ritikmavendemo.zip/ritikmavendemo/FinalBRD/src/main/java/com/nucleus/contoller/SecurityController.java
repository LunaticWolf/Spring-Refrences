package com.nucleus.contoller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class SecurityController {

	
	@RequestMapping(value = "/loginpage")
	public String handlerMethod1()
	{
		System.out.println("\n LOOgin form");
		return "login"; 
	}
		
		
		@RequestMapping(value="/loginfailure")
		public String handlerMethod2(ModelMap map)
		{
			map.addAttribute("errormsg", "bad credentials");
			return "login"; 
		}
		
		
		@RequestMapping(value="/noaccess")
		public String handlerMethod3()
		{
			return "noaccess"; 
		}

	
}
