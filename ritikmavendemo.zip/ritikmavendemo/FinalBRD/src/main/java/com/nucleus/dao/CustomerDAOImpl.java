package com.nucleus.dao;


import java.util.Date;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;




import com.nucleus.model.Customer;

@Repository
public class CustomerDAOImpl implements ICustomerDAO{

	@Autowired
SessionFactory sessionfactory;
public void insert(Customer customer) {

	customer.setRegisterationDate(new java.sql.Date(new Date().getTime()));
	sessionfactory.getCurrentSession().saveOrUpdate(customer);
	
}	

	public void delete(Customer customer) {
		sessionfactory.getCurrentSession().delete(customer);
     		
	}

	public Customer view(Customer customer) {
		int code= customer.getCustomerCode();
		System.out.println(code);
		Session session=sessionfactory.getCurrentSession();
	Customer c =(Customer)session.get(Customer.class,code); 
		return c;
	}

	public List<Customer> viewall(Customer customer) {
	
		return null;
	}

	public Customer update(Customer customer) {
		customer.setRegisterationDate(new java.sql.Date(new Date().getTime()));
		int code=customer.getCustomerCode();
		Session session =sessionfactory.getCurrentSession();
		Customer c = (Customer) session.get(Customer.class,code);
		return c;
	}
	public void insert2(Customer customer)
	{
		sessionfactory.getCurrentSession().saveOrUpdate(customer);
		
	}


	
	
}
