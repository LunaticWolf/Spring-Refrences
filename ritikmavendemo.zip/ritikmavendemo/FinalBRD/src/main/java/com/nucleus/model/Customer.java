package com.nucleus.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="FinalBRDCustomer")
public class Customer implements Serializable {


	private static final long serialVersionUID = 1L;

	@Id
	private int customerCode;
	private String customerName;
	private String customerAddress;
	private String customerPincode;
	private String customerEmail;
	private String contactNumber;
	private Date registerationDate;
	private String created_by;
	private Date modifiedDate;




	public Customer() {

	}


	public int getCustomerCode() {
		return customerCode;
	}




	public void setCustomerCode(int customerCode) {
		this.customerCode = customerCode;
	}




	public String getCustomerName() {
		return customerName;
	}




	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}




	public String getCustomerAddress() {
		return customerAddress;
	}




	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}




	public String getCustomerPincode() {
		return customerPincode;
	}




	public void setCustomerPincode(String customerPincode) {
		this.customerPincode = customerPincode;
	}




	public String getCustomerEmail() {
		return customerEmail;
	}




	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}




	public String getContactNumber() {
		return contactNumber;
	}




	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}




	public Date getRegisterationDate() {
		return registerationDate;
	}




	public void setRegisterationDate(Date registerationDate) {
		this.registerationDate = registerationDate;
	}




	public String getCreated_by() {
		return created_by;
	}




	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}




	public Date getModifiedDate() {
		return modifiedDate;
	}




	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}




	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	
	
	
	
	
	
	
}