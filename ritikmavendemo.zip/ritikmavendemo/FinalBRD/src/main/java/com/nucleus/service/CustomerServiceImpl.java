package com.nucleus.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import org.springframework.transaction.annotation.Transactional;

import com.nucleus.dao.ICustomerDAO;
import com.nucleus.model.Customer;

	@Service
	public class CustomerServiceImpl implements ICustomerService {

	@Autowired
	ICustomerDAO customerDAOImpl;
	@Transactional
		public void insert(Customer customer) {
		
			customerDAOImpl.insert(customer);
		}
	@Transactional
		public void delete(Customer customer) {
			customerDAOImpl.delete(customer);
			
		}
	@Transactional
	public Customer  view(Customer customer) {
		return	customerDAOImpl.view(customer);
		
	}
	public List<Customer> viewall(Customer customer) {
		
		return null;
	}
	@Transactional
	public Customer update(Customer customer) {
		
		return customerDAOImpl.update(customer);
	}
	@Transactional
	public void insert2(Customer customer) {
		customerDAOImpl.insert2(customer);
		
	}

	}
