package com.nucleus.contoller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.nucleus.model.Customer;
import com.nucleus.service.ICustomerService;


@Controller
public class CustomerController {

	@Autowired
	ICustomerService customerDAOImpl;


	/////Insert


	@RequestMapping("/Insert")
	public String handlerMethod( Customer customer)

	{
		return "insert";

	}

	@RequestMapping("/insertdone")
	public String Insert( Customer customer)

	{
		customerDAOImpl.insert(customer);
		return "success";

	}
	@RequestMapping("/Delete")
	public String handlerMethod1( Customer customer)

	{
		return "delete";

	}

	@RequestMapping("/deletedone")
	public String Delete( Customer customer)

	{
		customerDAOImpl.delete(customer);
		return "success";

	}
	@RequestMapping("/View")
	public String handlerMethod2( Customer customer)

	{
		return "retrieve";

	}

	@RequestMapping("/viewdone")
	public ModelAndView View( Customer customer)

	{
		Customer c=customerDAOImpl.view(customer);
		ModelAndView  model=new ModelAndView("view1");
	    model.addObject("listContact",c);
	   
	 
	    return model;
		

	}

	@RequestMapping("/Update")
	public String handlerMethod3( Customer customer)

	{
		return "update";

	}

	@RequestMapping("/updatedone")
	public ModelAndView update( Customer customer)

	{
		Customer c=customerDAOImpl.update(customer);
		ModelAndView  model=new ModelAndView("update1");
	    model.addObject("listContact",c);
	   
	 
	    return model;
		

	}
	@RequestMapping("/insert2done")
	public String insert2( Customer customer)

	{
		customerDAOImpl.insert(customer);
		return "update1";
		   		  
		

	}

	}
