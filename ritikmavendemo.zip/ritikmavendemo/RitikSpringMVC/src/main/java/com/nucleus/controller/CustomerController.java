package com.nucleus.controller;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.nucleus.modal.Customer;


@Controller 
@RequestMapping("/Customer")
public class CustomerController {

	
	@RequestMapping("/customerform")
	public String customerform(Customer customer)
	{
		
		return "Customerform";
	}
	
	@RequestMapping("/savecustomer")
	public ModelAndView savecustomer(@Valid Customer customer, BindingResult br)
	{
		if(br.hasErrors())
		{
			return new ModelAndView("Customerform");
		}
		
		return new ModelAndView("success","customer",customer);
	
	}
}
