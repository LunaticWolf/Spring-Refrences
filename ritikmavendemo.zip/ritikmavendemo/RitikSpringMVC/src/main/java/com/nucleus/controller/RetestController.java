package com.nucleus.controller;



import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.nucleus.modal.SimpleInterest;

@Controller
public class RetestController {
	
	
	@RequestMapping("/simpleinterestform")
	public String simpleinterestform(SimpleInterest simpleInterest)
	{
		
		return "simpleinterestform";
	}
	/*public ModelAndView simpleinterest1(SimpleInterest simpleInterest) { 
		
		return new ModelAndView("simpleinterestform","simpleInterest",simpleInterest);
	}
	*/
	
	/*@RequestMapping("/simpleinterest")  
    public ModelAndView simpleinterest5(SimpleInterest simpleInterest) { 
		
		System.out.println("Retest");
	int principal =	Integer.parseInt(simpleInterest.getPrincipal());
	int rate =	Integer.parseInt(simpleInterest.getRate());
	int time =	Integer.parseInt(simpleInterest.getTime());
	
		int si = (principal * rate *time)/100;
      //    System.out.println(si);
		System.out.println(" Obj"+simpleInterest);
		
      return new ModelAndView("simpleinterest", "SI", si);
      // return new ModelAndView("simpleinterest","simpleInterest",simpleInterest);
    }  
	*/
}
