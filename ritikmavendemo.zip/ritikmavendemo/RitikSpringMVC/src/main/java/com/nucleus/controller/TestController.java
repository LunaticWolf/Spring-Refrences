package com.nucleus.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class TestController {


	
/*	@RequestMapping("/success")  
    public ModelAndView helloWorld() {  
		System.out.println("@@@@@@@");
        String message = "HELLO SPRING MVC Demo";  
      return new ModelAndView("success", "message", message);
        //return new ModelAndView("success");
    }  */
	
	/*@RequestMapping("/simpleinterest")  
    public ModelAndView simpleinterest5(HttpServletRequest req) { 
		
		System.out.println("test");
	int principal =	Integer.parseInt(req.getParameter("principal"));
	int rate =	Integer.parseInt(req.getParameter("rate"));
	int time =	Integer.parseInt(req.getParameter("time"));
	int si = (principal*rate*time)/100;
          System.out.println(si);
      return new ModelAndView("simpleinterest", "SI", si);
      //  return new ModelAndView("simpleinterest");
    } */
	
	@RequestMapping("/simpleinterest")  
    public ModelAndView simpleinterest5(@RequestParam("principal") String p,@RequestParam("rate") String r,@RequestParam("time") String t ) { 
		
		System.out.println("test");
	int principal =	Integer.parseInt("p");
	int rate =	Integer.parseInt("r");
	int time =	Integer.parseInt("t");
	int si = (principal*rate*time)/100;
          System.out.println(si);
      return new ModelAndView("simpleinterest", "SI", si);
      //  return new ModelAndView("simpleinterest");
    }  
	
	
	
}
