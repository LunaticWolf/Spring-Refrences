package com.nucleus.modal;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;


public class Customer {

@Length(min=5,max=10)	
private String custfirstname;
@NotEmpty
private String custlastname;
public String getCustfirstname() {
	return custfirstname;
}
public void setCustfirstname(String custfirstname) {
	this.custfirstname = custfirstname;
}
public String getCustlastname() {
	return custlastname;
}
public void setCustlastname(String custlastname) {
	this.custlastname = custlastname;
}




}
	
	
