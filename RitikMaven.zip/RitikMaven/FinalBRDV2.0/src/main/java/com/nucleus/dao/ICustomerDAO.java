package com.nucleus.dao;

import java.util.List;
import com.nucleus.model.Customer;

public interface ICustomerDAO {
	public void insert(Customer customer);
public void delete(Customer customer);
public Customer view(Customer customer) ;
public List<Customer> viewall() ;
public Customer update(Customer customer);
public void insert2(Customer customer);

}
